// =====================================================================
// 自动分解模块（auto_salvage.js）—— 445 起独立功能模块，默认开启
// =====================================================================
// 做什么：
//   进 菜单 →「环境设定」→ 左侧「获得」→ 滚到最底部 → 找到
//   「可登录的收藏目标不在自动分解范围内」一行，把「开启 / 关闭」切到目标状态。
//   同时支持切到总开关行「获得道具自动分解」（config: row=master）。
//
// 截图证据（2026-11-14 01:48:55 / 01:49:03，1280x720）：
//   两张图逐像素对比，唯一变化区域是「可登录的收藏目标不在自动分解范围内」这一行：
//     01:48:55 → 关闭高亮；01:49:03 → 开启高亮。
//   总开关「获得道具自动分解」两张图都是开启。
//   高亮按钮平均亮度 ≈82，未选中 ≈13，亮度差极大，可可靠区分。
//
// 判定规则（严格按截图，用户口径）：
//   desired_on = true  → 「开启」高亮
//   desired_on = false → 「关闭」高亮
//   亮度差 < 25 个百分点 → 状态不明 → 不点，只记日志退出。
//
// 幂等：
//   已经是目标状态 → 不点击。
//
// 校准时机（445 最终口径）：
//   **只保留「进程启动后校准一次」**。
//   - 05:00 换日触发、配置变化触发已删除，不再自行打开设置页。
//   - bootDone / bootAttempts 都是进程内变量，不落盘：
//       本进程成功后永不再自动校准；失败最多重试 MAX_FAILS 次后停。
//   - 重装/重启 = 新进程 → 允许再校准一次；流程幂等，不会反复点击。
//   - 远程点名命令（dismantle-on/off）是显式触发，单独用 pendingCmd 补执行。
//
// 日志：
//   每一步都走 api.log，统一前缀 [自动分解]；结束再 api.event 一条汇总。
// =====================================================================

/* ============================ 常量区 ============================ */

// 默认目标：开启（用户要求“默认开启自动分解”）
var DEFAULT_ON = true;
// 默认目标行：收藏目标行（截图唯一变化的那一行）
var DEFAULT_ROW = "collect";
// 刚重启 20 秒截屏面还没建好，别急着跑
var BOOT_GRACE_MS = 20000;
// onTick 物理去抖（同一帧重复进入）
var CHECK_GAP_MS = 1000;
// 启动校准失败后 60 秒再试；连续 5 次失败后本进程停止自动校准
var FAIL_RETRY_MS = 60000;
var MAX_FAILS = 5;
// 远程命令补执行：最多 5 次、30 分钟内有效
var MAX_CMD_TRIES = 5;
var CMD_TTL_MS = 1800000;
// 滚到底最多滑几次
var SCROLL_MAX = 6;

// 菜单按钮（三条横线）
var MENU_BTN = [95.3, 4.2];
// 菜单面板右侧区域（找「环境设定」）
var MENU_PANEL = [50, 50, 100, 96];
// 菜单项「环境设定」兜底坐标（1280x720 → (1100,526)）
var ENV_ITEM_FALLBACK = [85.9, 73.1];
// 左栏「获得」区域与兜底坐标（1280x720 → (121,256)）
var NAV_COLLECT_R = [0, 20, 18, 70];
var COLLECT_FALLBACK = [9.5, 35.6];
// 环境设定页右上角「→]」返回箭头（禁止系统返回键）
var CLOSE_ARROW = [95.2, 5.3];

// 目标行两个按钮的横向范围（1280x720：开启 912-1084，关闭 1086-1244）
var BTN_ON_X = [71.3, 84.6];
var BTN_OFF_X = [84.9, 97.1];
// 判定阈值：亮点占比差 ≥ 25 个百分点才算看得清
var MIN_GAP = 25;

/* ============================ 运行态 ============================ */

var stateText = "待命";
var running = false;
var lastCheck = 0;
var bootAt = Date.now();
// 进程内：本次启动的自动校准是否已完成（成功/已是目标/放弃）
var bootDone = false;
// 进程内：本次启动已尝试次数（含失败重试）
var bootAttempts = 0;
// 远程命令待补执行：{want:boolean, until:number, tries:number}
var pendingCmd = null;
var lastFailAt = 0;
var failCount = 0;
var lastFailReason = "";
var _wh = null;

function setState(s) { stateText = s; }

/* ============================ 小工具 ============================ */

function desiredOn() {
    try { return api.loadConfigBool("desired_on", DEFAULT_ON); } catch (e) { return DEFAULT_ON; }
}

function desiredRow() {
    var r = "collect";
    try { r = String(api.loadConfig("row", DEFAULT_ROW)); } catch (e) { r = DEFAULT_ROW; }
    r = r.replace(/\s+/g, "");
    if (r !== "master") r = "collect";
    return r;
}

function lastApplied() {
    try { return String(api.loadConfig("last_applied", "")); } catch (e) { return ""; }
}

function targetWord() { return desiredOn() ? "开启" : "关闭"; }

function screenWh() {
    if (_wh != null) return _wh;
    var s = null;
    try { s = api.screenshot(); } catch (e) { s = null; }
    if (s != null && s.w > 0 && s.h > 0) _wh = [s.w, s.h];
    else _wh = [1280, 720];
    return _wh;
}

function pxY(y) {
    var h = screenWh()[1];
    var p = y * 100 / h;
    if (p < 0) p = 0;
    if (p > 100) p = 100;
    return p;
}

function tapPct(p, why) {
    var wh = screenWh();
    var x = Math.round(wh[0] * p[0] / 100);
    var y = Math.round(wh[1] * p[1] / 100);
    var ok = false;
    try { ok = api.tap(x, y); } catch (e) { ok = false; }
    api.log("[自动分解] 点击 " + why + " @(" + x + "," + y + ") → " + (ok ? "已派发" : "被拒"));
    return ok;
}

function tapPx(x, y, why) {
    var ok = false;
    try { ok = api.tap(x, y); } catch (e) { ok = false; }
    api.log("[自动分解] 点击 " + why + " @(" + x + "," + y + ") → " + (ok ? "已派发" : "被拒"));
    return ok;
}

function findIn(word, region) {
    try { return api.find(word, region); } catch (e) { return null; }
}

function findAny(words, region) {
    for (var i = 0; i < words.length; i++) {
        var h = findIn(words[i], region);
        if (h != null) return { hit: h, word: words[i] };
    }
    return null;
}

function ocrTexts(region) {
    var out = [];
    try {
        var arr = api.ocr(region);
        for (var i = 0; i < arr.length; i++) out.push(String(arr[i].text));
    } catch (e) { }
    return out;
}

function fullText() {
    var arr = [];
    try {
        var items = api.ocr([0, 10, 100, 100]);
        for (var i = 0; i < items.length; i++) arr.push(String(items[i].text));
    } catch (e) { }
    return arr.join("|");
}

function isMain() {
    try { return api.isOnMainHud(); } catch (e) { return false; }
}

function ensureMainHud() {
    if (isMain()) return true;
    try { api.ensureHome("自动分解"); } catch (e) { }
    var ok = isMain();
    if (!ok) api.log("[自动分解] 归位失败：当前不在主城，按规矩不点，下一轮再试");
    return ok;
}

function bright(rect, threshold) {
    try { return api.brightRatio(rect, threshold); } catch (e) { return 0; }
}

/* ============================ 导航 ============================ */

function menuHasEnv() {
    return findAny(["环境设定", "环境设", "境设定"], MENU_PANEL) != null;
}

function openMenu() {
    if (menuHasEnv()) { api.log("[自动分解] 菜单已打开（认出「环境设定」）"); return true; }
    if (!isMain()) {
        api.log("[自动分解] 点菜单前不在主城（疑似弹窗/面板残留）→ 本轮不做");
        return false;
    }
    tapPct(MENU_BTN, "菜单按钮");
    var deadline = Date.now() + 8000;
    while (Date.now() < deadline) {
        api.sleep(600);
        if (menuHasEnv()) { api.log("[自动分解] 菜单已打开（认出「环境设定」）"); return true; }
        if (findIn("每日", [52, 40, 90, 60]) != null) {
            api.log("[自动分解] 菜单已打开（认出「每日」）");
            return true;
        }
    }
    api.log("[自动分解] 菜单没打开：8 秒内认不到「环境设定」");
    return false;
}

function tapEnvItem() {
    var hit = findAny(["环境设定", "环境设", "境设定"], MENU_PANEL);
    if (hit != null) {
        api.log("[自动分解] 菜单 OCR「" + hit.hit.text + "」@(" + hit.hit.cx + "," + hit.hit.cy + ")");
        return tapPx(hit.hit.cx, hit.hit.cy, "菜单·环境设定");
    }
    api.log("[自动分解] 菜单里没认出「环境设定」，用兜底坐标");
    return tapPct(ENV_ITEM_FALLBACK, "菜单·环境设定(兜底)");
}

function waitEnvPage() {
    var deadline = Date.now() + 8000;
    var last = "";
    while (Date.now() < deadline) {
        var top = findAny(["环境设定", "环境设", "境设定"], [0, 0, 100, 14]);
        var body = findAny(["强化失败", "获得道具自动分解", "没有分解工具"], [18, 10, 100, 100]);
        last = (top != null ? top.hit.text : "") + "/" + (body != null ? body.hit.text : "");
        if (top != null || body != null) {
            api.log("[自动分解] 环境设定页已打开（OCR「" + last + "」）");
            return true;
        }
        api.sleep(700);
    }
    api.log("[自动分解] 环境设定页没打开（8 秒内 OCR「" + last + "」）");
    return false;
}

function tapCollectTab() {
    var hit = findIn("获得", NAV_COLLECT_R);
    if (hit != null) {
        api.log("[自动分解] 左栏 OCR「" + hit.text + "」@(" + hit.cx + "," + hit.cy + ")");
        return tapPx(hit.cx, hit.cy, "左栏·获得");
    }
    api.log("[自动分解] 左栏没认出「获得」，用兜底坐标");
    return tapPct(COLLECT_FALLBACK, "左栏·获得(兜底)");
}

function waitCollectPage() {
    var deadline = Date.now() + 7000;
    var last = "";
    while (Date.now() < deadline) {
        var hit = findAny(["强化失败", "获得道具自动分解", "没有分解工具"], [18, 10, 100, 100]);
        if (hit != null) {
            api.log("[自动分解] 「获得」页已打开（OCR「" + hit.hit.text + "」）");
            return true;
        }
        last = ocrTexts([18, 10, 100, 60]).join("|");
        api.sleep(700);
    }
    api.log("[自动分解] 「获得」页没打开（7 秒内 OCR「" + last + "」）");
    return false;
}

function swipeUp() {
    var wh = screenWh();
    var x = Math.round(wh[0] / 2);
    var y1 = Math.round(wh[1] * 0.86);
    var y2 = Math.round(wh[1] * 0.33);
    var ok = false;
    try { ok = api.swipe(x, y1, x, y2, 700); } catch (e) { ok = false; }
    return ok;
}

// 滚到最底：连续两次页面文本不变且出现底部特征词
function scrollToBottom() {
    var prev = "";
    for (var i = 0; i < SCROLL_MAX; i++) {
        swipeUp();
        api.sleep(900);
        var txt = fullText();
        var hasBottom = txt.indexOf("没有分解工具") >= 0 || txt.indexOf("收藏目标") >= 0;
        if (hasBottom && txt === prev) {
            api.log("[自动分解] 已滚到底（第 " + (i + 1) + " 次滑动后文本稳定）");
            return true;
        }
        prev = txt;
    }
    var ok = prev.indexOf("没有分解工具") >= 0 || prev.indexOf("收藏目标") >= 0;
    api.log("[自动分解] 滚到底结果：" + (ok ? "已看到底部特征词" : "仍未看到底部特征词")
            + "（已滑 " + SCROLL_MAX + " 次）");
    return ok;
}

/* ============================ 目标行定位 / 判定 ============================ */

// 返回 {cy, text}；找不到返回 null
function findTargetRow(row) {
    var keys = row === "master"
            ? ["获得道具自动分解", "获得道具自动分", "得道具自动分解"]
            : ["可登录的收藏目标", "收藏目标不在", "可登录的收藏", "收藏目标"];
    var items = [];
    try { items = api.ocr([0, 12, 100, 100]); } catch (e) { items = []; }
    var hits = [];
    for (var i = 0; i < items.length; i++) {
        var t = String(items[i].text == null ? "" : items[i].text).replace(/\s+/g, "");
        for (var k = 0; k < keys.length; k++) {
            if (t.indexOf(keys[k]) >= 0) {
                hits.push({ cy: items[i].cy, cx: items[i].cx, text: String(items[i].text) });
                break;
            }
        }
    }
    if (hits.length === 0) return null;
    // master 行会同时命中「获得道具自动分解」小节标题和行标题，取最靠下的那条（行标题）
    var best = hits[0];
    for (var j = 1; j < hits.length; j++) {
        if (hits[j].cy > best.cy) best = hits[j];
    }
    api.log("[自动分解] 目标行命中 " + hits.length + " 条，取最靠下：OCR「" + best.text
            + "」cy=" + best.cy + "（候选：" + hits.length + "）");
    return best;
}

// 读某一行两个按钮的高亮状态；返回 true/false/null(不明)
function readRowState(cy) {
    var y0 = pxY(cy - 24);
    var y1 = pxY(cy + 24);
    var onRect = [BTN_ON_X[0], y0, BTN_ON_X[1], y1];
    var offRect = [BTN_OFF_X[0], y0, BTN_OFF_X[1], y1];

    var on90 = bright(onRect, 90);
    var off90 = bright(offRect, 90);
    var state = decideGap(on90, off90);
    if (state == null) {
        var on60 = bright(onRect, 60);
        var off60 = bright(offRect, 60);
        state = decideGap(on60, off60);
        on90 = on90 + "/" + on60;
        off90 = off90 + "/" + off60;
    }
    var texts = ocrTexts([BTN_ON_X[0], y0, BTN_OFF_X[1], y1]).join("|");
    api.log("[自动分解] 读数 cy=" + cy + "：开启亮点=" + on90 + "%，关闭亮点=" + off90
            + "% → " + (state == null ? "不明" : (state ? "开启" : "关闭"))
            + "（按钮区 OCR「" + (texts || "空") + "」）");
    return state;
}

function decideGap(a, b) {
    if (a - b >= MIN_GAP) return true;
    if (b - a >= MIN_GAP) return false;
    return null;
}

function verifyState(cy, want) {
    for (var i = 0; i < 4; i++) {
        api.sleep(900);
        var st = readRowState(cy);
        if (st === want) return true;
    }
    return false;
}

/* ============================ 关闭页面 ============================ */

function closeSettings() {
    for (var i = 0; i < 2; i++) {
        if (isMain()) { api.log("[自动分解] 已在主城"); return true; }
        tapPct(CLOSE_ARROW, "环境设定右上返回箭头");
        var deadline = Date.now() + 5000;
        while (Date.now() < deadline) {
            api.sleep(600);
            if (isMain()) { api.log("[自动分解] 已用右上返回箭头关掉环境设定"); return true; }
        }
    }
    api.log("[自动分解] 关闭环境设定后仍未回主城（不按系统返回键，下一轮再关）");
    return false;
}

/* ============================ 主流程 ============================ */

function doCalibrate(reason, manual) {
    if (running) { api.log("[自动分解] 已在校准中，忽略本次触发（" + reason + "）"); return false; }
    running = true;
    setState("校准中…");
    var startMs = Date.now();
    var want = desiredOn();
    var row = desiredRow();
    var wantWord = want ? "开启" : "关闭";
    api.log("[自动分解] ===== 开始校准（" + reason + "）：目标=" + wantWord
            + "，行=" + row + " =====");
    try {
        if (!isMain()) {
            if (!ensureMainHud()) return finishFail(startMs, "不在主城，归位失败", manual);
        }
        if (!openMenu()) return finishFail(startMs, "菜单没打开", manual);
        if (!tapEnvItem()) return finishFail(startMs, "「环境设定」点击被拒", manual);
        if (!waitEnvPage()) {
            closeSettings();
            return finishFail(startMs, "环境设定页没打开", manual);
        }
        if (!tapCollectTab()) return finishFail(startMs, "「获得」点击被拒", manual);
        if (!waitCollectPage()) {
            closeSettings();
            return finishFail(startMs, "「获得」页没打开", manual);
        }
        if (!scrollToBottom()) {
            closeSettings();
            return finishFail(startMs, "没滚到底/认不到底部", manual);
        }

        var rowHit = findTargetRow(row);
        if (rowHit == null) {
            closeSettings();
            return finishFail(startMs, "目标行未找到（row=" + row + "）", manual);
        }
        var cy = rowHit.cy;

        var st = readRowState(cy);
        if (st == null) {
            closeSettings();
            return finishFail(startMs, "状态不明（亮点差 < " + MIN_GAP + "），按规矩不点", manual);
        }
        if (st === want) {
            persist(row, want);
            closeSettings();
            api.log("[自动分解] 已是目标状态（" + wantWord + "），不点击；目标行 cy=" + cy);
            return finishOk(startMs, "已是目标", wantWord, cy);
        }

        var x = want ? 998 : 1165;
        api.log("[自动分解] 当前=" + (st ? "开启" : "关闭") + "，目标=" + wantWord
                + " → 点击「" + wantWord + "」@(" + x + "," + cy + ")");
        tapPx(x, cy, "目标按钮·" + wantWord);
        var ok = verifyState(cy, want);
        if (!ok) {
            api.log("[自动分解] 第一次点击后复查未达成，再点一次");
            tapPx(x, cy, "目标按钮·" + wantWord + "(补点)");
            ok = verifyState(cy, want);
        }
        if (!ok) {
            closeSettings();
            return finishFail(startMs, "点击后复查未达成（目标=" + wantWord + "）", manual);
        }

        persist(row, want);
        closeSettings();
        return finishOk(startMs, "已切换", wantWord, cy);
    } catch (e) {
        try { api.warn("[自动分解] 校准异常：" + e); } catch (e2) { }
        try { closeSettings(); } catch (e3) { }
        return finishFail(startMs, "校准异常：" + e, manual);
    } finally {
        running = false;
    }
}

function persist(row, want) {
    try {
        api.putConfig("last_applied", want ? "on" : "off");
        api.putConfig("last_row", row);
        api.putConfig("last_at", String(Date.now()));
    } catch (e) { }
}

function finishOk(startMs, how, wantWord, cy) {
    var sec = Math.max(1, Math.round((Date.now() - startMs) / 1000));
    failCount = 0;
    lastFailReason = "";
    // 本进程的自动校准到此结束；远程命令也算完成
    bootDone = true;
    pendingCmd = null;
    setState(wantWord === "开启" ? "已开启" : "已关闭");
    var msg = "校准完成：" + how + "，目标=" + wantWord + "，行cy=" + cy + "，用时 " + sec + "s";
    api.log("[自动分解] " + msg);
    try { api.event("[自动分解] " + msg); } catch (e) { }
    return true;
}

function finishFail(startMs, why, manual) {
    var sec = Math.max(1, Math.round((Date.now() - startMs) / 1000));
    lastFailAt = Date.now();
    failCount = failCount + 1;
    lastFailReason = why;
    if (failCount >= MAX_FAILS) {
        bootDone = true;
        if (pendingCmd != null) pendingCmd = null;
    }
    setState("失败：" + why);
    api.log("[自动分解] 本轮未完成：" + why + "，用时 " + sec + "s；连续失败 "
            + failCount + " 次" + (bootDone ? "（已到上限，本进程不再自动校准）" : "（60s 后重试）"));
    try { api.event("[自动分解] 未完成：" + why + "（连续 " + failCount + " 次）"); } catch (e) { }
    return false;
}

/* ============================ onTick（轻，禁 sleep/OCR） ============================ */

function onTick(nowMs) {
    if (running) return false;
    if (!api.loadConfigBool("on", true)) return false;       // 模块未勾选
    if (Date.now() - lastCheck < CHECK_GAP_MS) return false;
    lastCheck = Date.now();
    if (Date.now() - bootAt < BOOT_GRACE_MS) return false;   // 刚重启，等截屏就绪
    if (!api.gameInProgress()) return false;
    if (!api.captureRunning()) return false;
    if (api.stepsRunning()) return false;
    if (api.autoDailyScheduling()) return false;
    var st = "idle";
    try { st = String(api.longTaskState()); } catch (e) { st = "idle"; }
    if (st !== "idle" && st !== "hang") return false;        // 副本/神谕/进游戏让路

    var why = "";

    // ① 远程点名命令：显式触发，最多补 MAX_CMD_TRIES 次
    if (pendingCmd != null) {
        if (Date.now() > pendingCmd.until || pendingCmd.tries >= MAX_CMD_TRIES) {
            api.log("[自动分解] 远程命令补执行超时/到次数上限，放弃（目标="
                    + (pendingCmd.want ? "开启" : "关闭") + "，已试 " + pendingCmd.tries + " 次）");
            pendingCmd = null;
        } else {
            pendingCmd.tries = pendingCmd.tries + 1;
            why = "远程命令补执行（第 " + pendingCmd.tries + " 次）";
        }
    }

    // ② 启动后校准一次：本进程只走这一条自动触发
    if (why === "" && !bootDone) {
        if (failCount > 0 && Date.now() - lastFailAt < FAIL_RETRY_MS) return false;
        bootAttempts = bootAttempts + 1;
        why = "启动后校准一次（第 " + bootAttempts + " 次）";
    }

    if (why === "") return false;

    setState("该校准了：" + why);
    api.log("[自动分解] 触发校准：" + why + "（目标=" + (desiredOn() ? "开启" : "关闭") + "）");
    return true;   // 请求宿主起脚本线程执行 runOnce
}

/* ============================ MOD 导出 ============================ */

var MOD = {
    id: "auto_salvage",
    title: "自动分解",
    desc: "环境设定→获得→收藏目标自动分解范围；默认开启（可切总开关行）",
    defaultEnabled: true,
    order: 24,
    status: function () {
        if (!api.loadConfigBool("on", true)) return "未勾选";
        if (running) return "校准中";
        var want = desiredOn();
        var last = lastApplied();
        if (last === (want ? "on" : "off")) return want ? "已是开启" : "已是关闭";
        if (pendingCmd != null) return "待补执行";
        if (failCount > 0) return "待重试：" + lastFailReason;
        if (bootDone) return "本进程已校过";
        return "待校准";
    },
    onTick: onTick,
    runOnce: function (reason) {
        var why = reason == null ? "手动" : String(reason);
        var manual = why.indexOf("手动") === 0;
        // 远程命令通道：runOnce("远程命令:on|off")，先落目标再登记补执行
        var m = /远程命令:(on|off)/.exec(why);
        if (m != null) {
            try {
                api.putConfig("desired_on", m[1] === "on");
                api.putConfig("row", DEFAULT_ROW);
            } catch (e) { }
            pendingCmd = { want: m[1] === "on", until: Date.now() + CMD_TTL_MS, tries: 0 };
            api.log("[自动分解] 收到远程命令：目标=" + (m[1] === "on" ? "开启" : "关闭")
                    + "（已落配置，屏幕忙时由 onTick 补执行）");
        }
        if (manual) { failCount = 0; lastFailAt = 0; bootDone = true; }
        if (api.stepsRunning()) {
            api.log("[自动分解] 有步骤脚本在跑，本次不执行（" + why + "）");
            return false;
        }
        var st = "idle";
        try { st = String(api.longTaskState()); } catch (e) { st = "idle"; }
        if (st !== "idle" && st !== "hang") {
            api.log("[自动分解] 长任务在跑（" + st + "），本次不执行（" + why + "）");
            return false;
        }
        return doCalibrate(why, manual);
    }
};

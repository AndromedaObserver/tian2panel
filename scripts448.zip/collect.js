// =====================================================================
// 自动收藏模块（collect.js）—— v2.0.0 由原生 CollectionModule 迁入脚本层
// =====================================================================
// 做什么：把背包里能「安全收藏」的装备强化到图鉴要求的档位后收藏掉
//（收藏 = 装备消失、负重下降），要求超安全上限的才分解。
//
// 主流程（顺序固定，不许边查边碎）：
//   阶段A 扫描：背包逐格读装备 → 菜单→收藏 打开图鉴 → 遍历全部分页 →
//         收集所有「亮」列 → 逐列读 req_levels。
//   阶段B 收藏：过滤 ≤ 安全上限（武器 ≤+6、防具 ≤+4）→ 取最低档 → 回背包
//         逐级强化到目标档 → 进图鉴点对应条目 → 以「该列由亮变暗」为唯一成功判据。
//   阶段C 清理：退出图鉴回背包 → 对「待分解列表」逐件分解（选中→长按→分解→确认）
//         → 以「装备从背包消失」为唯一成功判据 → 回到阶段A循环。
//
// 血泪教训（全部来自 2026-11-01/02 实测，迁 JS 时原样保留）：
//   · v1.9.04 假成功 20 件：收藏成功判据用了「弹没弹确认框」，OK_WORDS 里的泛词
//     命中正文 → 点正文还报成功。所以：弹窗词表只放「确定/确认」，
//     成功判据只有亮变暗/装备消失。
//   · 「43%」这类小字 OCR 认不出 → 一律走 api.ocrBig 放大。
//   · 坐标没实测过的一律 OCR 定位再点，找不到就记日志跳过，绝不赌坐标连点。
//   · 紫装（英雄级）和红装不能收藏也不能分解；穿在身上的装备不能收藏。
// =====================================================================

// —— 模块注册 / 加载 / 兜底（核心层 ScriptHost，只读说明）——
// · ModuleManager 调 ScriptHost.build("collect.js", CollectionModule 实例)。ScriptEngine 就绪且
//   本文件存在 MOD 对象 → 返回 ScriptModule（JS 驱动）；面板上的 id/title/order/defaultEnabled
//   取自本文件末尾的 MOD（id="collect" / order=31 / defaultEnabled=true），不取 Java 的 CollectionModule。
// · MOD.id 必须与 Java CollectionModule.id() 一致（"collect"）：DailyPlan/远程指令/占屏凭据
//   holdScreen("collect") 都按这个 id 关联。
// · 文件缺失 / Rhino 编译或求值抛错 / MOD 不是对象 → ScriptHost.build 打警告并回退 Java
//   CollectionModule（JS 优先、Java 兜底），本文件不再参与运行。
// · 热更：ScriptUpdateManager 解包后 ScriptHost.reloadScriptModules() 原地重估；isRunning() 时推迟。
// · 宿主调用面：MOD.status()（UI 线程）、MOD.onTick(nowMs)（UI 线程，必须轻）、
//   MOD.runOnce(reason)（脚本线程，里面才允许 sleep/OCR/点屏）。

/* ============================ 常量区（全部集中在这，热改只动这里） ============================ */

// 武器/防具强化安全上限（含）。超过就爆装风险，绝不多点一下
var CAP_WEAPON = 6;
var CAP_ARMOR = 4;

// 点击/切换类动作的重试上限
var RETRY_TAP = 3;
// 收藏点击后列没变暗的重试次数
var RETRY_COLLECT = 2;
// 单次强化没生效的重试上限（材料不足/次数用尽就放弃该件）
var ENHANCE_RETRY = 2;
// 单件强化动作总步数兜底（防 OCR 读错等级导致死循环）
var ENHANCE_MAX_STEPS = 8;

// 点按钮后等界面刷新
var WAIT_UI = 1400;
// 开关面板/切分页这类大切换的等待
var WAIT_PAGE = 2400;
// 一次强化动画的等待
var WAIT_ENHANCE = 2600;
// 等列变暗的总超时 / 变暗轮询间隔
var SLOT_DIM_TIMEOUT = 7000;
var DIM_POLL_GAP = 900;
// 长按时长（ms）
var LONG_PRESS_MS = 900;

// 亮暗判定：列区域亮度 ≥ BRIGHT_MIN_LUMA 的像素占比 ≥ BRIGHT_MIN_RATIO → 亮（未收藏）
var BRIGHT_MIN_LUMA = 110;
var BRIGHT_MIN_RATIO = 6;

// 小字 OCR 放大目标宽度（1280 最稳）
var OCR_BIG_W = 1280;
// 图鉴分页数量上限 / 主循环轮数上限
var MAX_PAGES = 8;
var MAX_ROUNDS = 5;
// 列聚类：x 中心差超过这个像素（真实屏幕坐标）就算另一列
var COL_GAP_PX = 90;
// 单页最多处理的亮列数（防 OCR 误判刷出一堆假列）
var MAX_SLOTS_PER_PAGE = 12;
// 列外接框外扩像素（亮暗采样用）
var COL_PAD_PX = 40;

/* ============================ 坐标 / 区域（1280x720 真机标定） ============================ */

// 主界面右上角负重按钮，点它开背包（2026-11-02 实测 (1028,60)）
// 2026-11-03 实拍：背包入口是百分比文字正上方的图标，实测 (1031,32) 一点就开
var X_BAG_ICON = 1031, Y_BAG_ICON = 32;
// 背包物品格中心：4 列 × 5 行（实测像素剖面）
// TODO(待确认): 本文件 GX/GY 与 bag.js、BagModule、CollectionModule 的标定值不同
//   （此处 987/1057/1127/1197 与 185/250/317/385/452；另两处 990/1063/1136/1209 与
//   178/250/322/394/466），哪一套是真机准值无法从代码判断，点格子前需再标定一次。
var GX = [987, 1057, 1127, 1197];   // 2026-11-03 实拍 4 列
var GY = [185, 250, 317, 385, 452];   // 2026-11-03 实拍行距≈67
// 背包底栏「详情」
var X_INFO = 1061, Y_INFO = 576;
// 2026-11-03 实拍 find 实测：「收藏」按钮在第一排第 2 个 (1053,518)
var X_FAV = 1053, Y_FAV = 518;
// 详情面板右上角 X（关详情）
var X_CLOSE = 1223, Y_CLOSE = 95;
// v416：副页右上「→]」返回箭头（btnlib: ui.back_arrow，1280x720 实拍 rect 1204,10-1252,62）
// 铁律：任何"返回"都只点这个图标或页面自己的 X/箭头，绝不注入系统返回键。
var UI_BACK = [1228, 36];
// 图鉴页右上返回箭头（2026-11-04 实拍 1237,21）
var X_BK_CLOSE = 1237, Y_BK_CLOSE = 21;
// 详情面板底部第二排「分解」（灰字 OCR 常认不出，坐标固定，长按失败后的兜底）
var X_BREAK = 1103, Y_BREAK = 594;
// 「强化」的兜底候选点：和分解同一排、在其左侧（未实测，OCR 优先）
var X_ENH_CAND = 1030, Y_ENH_CAND = 594;

// 右侧详情面板整体（认装备类型用）
// 2026-11-03：全区域 OCR 要 8~10 秒/格，20 格就是 3 分钟。名字/类型/攻防属性
// 全在详情上半部分，扫到 52% 就够，时间砍一半以上。
var R_DETAIL = [56, 6, 100, 52];
// 详情面板底部按钮排（强化/分解/删除）
// 2026-11-03 实拍：详情底部是两排按钮 —— 第一排 出售/收藏/对比/装备(y≈494)，
// 第二排 移动/强化/分解/删除(y≈545)。原框只到第二排，找不到「收藏」。
var R_DETAIL_BTN = [56, 62, 100, 96];
// 详情面板顶部装备名
// 2026-11-03 实拍：详情面板的装备名在顶部一行（y≈80~112），
// 原来 [56,18,100,26]（y130~187）框住的是背包「全部 91/124」标题 →
// 每格都读成「全部」，这就是「扫 20 格全是同一件」的真因。改成只框标题行。
var R_NAME = [82, 10, 98, 17];
// 主界面右上「43%」
// 2026-11-03 实拍（HUD OCR 实测）：右上角一排是 活动(904) 商店(965) [56%](1031) 技能(1091) 任务(1155) 菜单(1216)，
// 百分比文字 bbox 1014~1047 / 51~69 → 79.2%~81.8% × 7.1%~9.6%。
// ★ 上一版误改成 63~71%（806~909，那是「活动」左边的空白），反而读不到，这里改回并收紧。
var R_WEIGHT = [78, 6, 83, 11];
// 窄框认不出时兜底扫整个右上角（UI 挪位/百分比变小的情况下窄框会整块空掉）
var R_WEIGHT_WIDE = [74, 2, 100, 13]; // 整条 HUD 右段兜底
// 屏幕正中确认框
var R_DIALOG = [25, 25, 75, 80];
// 背包面板打开后会出现的字
var R_BAG_OPEN = [68, 12, 99, 30];

/* ============================ 词表（铁律：无泛词） ============================ */

// 背包面板标题/分类词（判定背包开着）
var BAG_OPEN_WORDS = ["背包", "全部", "装备", "材料", "整理", "批量"];
// 「菜单」按钮词。实测 OCR 会把「菜单」认成「买单」，一起放进来
var MENU_WORDS = ["菜单", "买单", "莱单"];
// 2026-11-03 实拍：菜单网格最右列「收藏」，文字中心 (1217,157)，图标本体在其上方 30px
var X_BOOK_ICON = 1217, Y_BOOK_ICON = 127;
// 主界面右上「菜单」按钮：bbox 1197~1236 / 47~73（跨上百张截图没挪过）
var X_MENU = 1216, Y_MENU = 59;
// 菜单面板里图鉴入口的词
var BOOK_ENTRY_WORDS = ["收藏"];
// 图鉴分页签词表（认不出哪个页就跳过哪个页，绝不赌坐标）
var PAGE_WORDS = ["普通", "高级", "稀有", "史诗", "传说", "英雄", "精英", "特殊"];
// 图鉴打开判定的兜底词
var BOOK_OPEN_WORDS = ["图鉴", "普通", "高级", "稀有", "史诗", "传说"];

/**
 * 确认框按钮词表。
 * ★ 绝对不放「收藏」「是」这类泛词：弹窗正文写着「收藏后该道具将消失」，
 *   contains 匹配会命中正文，点正文等于什么都没点还报成功 —— v1.9.04 假成功 20 件的根因。
 */
var OK_WORDS = ["确定", "确认"];

// 装备名尾部等级后缀（「重罚之剑-2」的 -2）；负重百分比（「43%」）
// 收藏要求条目「+N」的正则在 parseReq 里（全局匹配，exec 串行推进）
var P_LV = /[-+]\s*(\d{1,2})\s*$/;
var P_PCT = /(\d{1,3})\s*%/;

/* ============================ 运行态 ============================ */

var stateText = "待命";
// 上一轮背包扫描结果（findInBag 先按记录的格子直接验，省 20 次 OCR）
var lastInv = [];
// 分页签所在行的 y 百分比（首次认出分页后记下来，后面只扫这一条）
var tabRowPct = -1;

/* ============================ 工具函数 ============================ */

// 文本归一：null→""、去半角/全角空格、trim。所有词表 contains 比较前都先过它。
function norm(s) { return (s == null ? "" : String(s)).replace(/ /g, "").replace(/\u3000/g, "").trim(); }

// 安全十进制解析：NaN 时返回 def（全项目用 -1 表示「读不到」）；范围校验交给调用方。
function parseIntSafe(s, def) {
    var v = parseInt(String(s).trim(), 10);
    return isNaN(v) ? def : v;
}

// 文本里的收藏要求等级（「+6」「强化+6」→ 6），没有返回 null
// Java 版用 while(m.find()) 遍历全部「+N」；JS 版手动推进 lastIndex 等价实现
function parseReq(text) {
    if (text == null) return null;
    var s = norm(text);
    var re = /\+\s*(\d{1,2})/g;
    var m;
    while ((m = re.exec(s)) != null) {
        var v = parseIntSafe(m[1], -1);
        if (v > 0 && v <= 15) return v;
    }
    return null;
}

// 装备强化等级。两种格式都要认：
//   详情面板：「+4 卡勒米安外衣（刻印）」→ 4（等级在**前缀**）
//   图鉴条目：「普通单手剑套装-2」        → 2（等级在后缀）
// 2026-11-03 实测：原来只认后缀，结果每件都读成 +0（画面明明是 +4），
// 会重复强化、甚至把已经超上限的装备继续往上砸 —— 危险。
function parseLevel(name) {
    if (name == null) return null;
    var s = String(name).trim();
    var m = /^[+]\s*(\d{1,2})/.exec(s);          // 「+4 …」
    if (m) {
        var v0 = parseIntSafe(m[1], -1);
        if (v0 >= 0 && v0 <= 15) return v0;
    }
    m = /[-+]\s*(\d{1,2})\s*$/.exec(s);         // 「…-2」
    if (m) {
        var v = parseIntSafe(m[1], -1);
        if (v >= 0 && v <= 15) return v;
    }
    return null;
}

// 去掉等级（前缀「+4 」/ 后缀「-2」）和「（刻印）」这类括号后缀，只留装备本体名
function baseName(name) {
    if (name == null) return "";
    var s = String(name).replace(/[-+]\s*\d{1,2}\s*$/, "").trim();
    s = s.replace(/^[+]\s*\d{1,2}\s*/, "").trim();
    s = s.replace(/[（(].*$/, "").trim();
    return s;
}

// 最长公共子序列长度（判断两个词像不像）
// 最长公共子序列长度（O(n·m) 双行滚动数组，只用于下面 similar 的容错比较）。
// 入参 a/b 为字符串；任一为空返回 0。无副作用。
function lcs(a, b) {
    var n = a.length, m = b.length;
    if (n === 0 || m === 0) return 0;
    var prev = [], cur = [];
    for (var j = 0; j <= m; j++) { prev.push(0); cur.push(0); }
    for (var i = 1; i <= n; i++) {
        for (var j2 = 1; j2 <= m; j2++) {
            cur[j2] = a.charAt(i - 1) === b.charAt(j2 - 1)
                ? prev[j2 - 1] + 1 : Math.max(prev[j2], cur[j2 - 1]);
        }
        for (var k = 0; k <= m; k++) { prev[k] = cur[k]; cur[k] = 0; }
    }
    return prev[m];
}

// 模糊匹配：长度差 ≤1 且公共子序列 ≥ 短词长度-1（美术字常见一字识别错误）
function similar(a, b) {
    var s = a.length <= b.length ? a : b;
    var t = a.length <= b.length ? b : a;
    if (s.length < 2 || t.length - s.length > 1) return false;
    return lcs(s, t) >= s.length - 1;
}

// 两件装备是不是同一件：去等级后缀后比较（完全相等 / 包含 / 容错差一字）
function sameItem(a, b) {
    var sa = baseName(norm(a)), sb = baseName(norm(b));
    if (sa.length === 0 || sb.length === 0) return false;
    if (sa === sb) return true;
    if (sa.indexOf(sb) >= 0 || sb.indexOf(sa) >= 0) return true;
    return similar(sa, sb);
}

// 分页词容错匹配（精确 → 包含 → 容错）
function matchPageWord(s) {
    for (var p = 0; p < 3; p++) {
        for (var i = 0; i < PAGE_WORDS.length; i++) {
            var w = PAGE_WORDS[i];
            if ((p === 0 && s === w) || (p === 1 && s.indexOf(w) >= 0)
                || (p === 2 && similar(s, w))) return w;
        }
    }
    return null;
}

// 在 OCR 结果里找词表里的词（精确 → 包含 → 容错）
function findWord(items, words) {
    for (var pass = 0; pass < 3; pass++) {
        for (var i = 0; i < items.length; i++) {
            var s = norm(items[i].text);
            for (var w = 0; w < words.length; w++) {
                if ((pass === 0 && s === words[w])
                    || (pass === 1 && s.indexOf(words[w]) >= 0)
                    || (pass === 2 && similar(s, words[w]))) return items[i];
            }
        }
    }
    return null;
}

// 图鉴列 ↔ 背包装备配对
function matchItem(inv, name) {
    for (var i = 0; i < inv.length; i++) {
        if (sameItem(inv[i].name, name)) return inv[i];
    }
    return null;
}

// 把一页 OCR 块拼成快照串（text+"|"），用于「切页前后画面是否相同」的校验。
// 入参 blocks=OCR 块数组；返回 String（空页返回 ""）。无副作用。
function snapshot(blocks) {
    var s = "";
    for (var i = 0; i < blocks.length; i++) s += blocks[i].text + "|";
    return s;
}

// 日志摘要：前 max 块拼「文本(cx,cy) | …」，超出的块只报总数。仅供日志，无副作用。
function summaryOf(items, max) {
    var sb = [];
    for (var i = 0; i < items.length && i < max; i++) {
        sb.push(items[i].text + "(" + items[i].cx + "," + items[i].cy + ")");
    }
    return sb.join(" | ") + (items.length > max ? " …共 " + items.length + " 块" : "");
}

// 只改内存状态文本（MOD.status 读它）；无点屏/写盘副作用。
function setState(s) {
    stateText = s;
}

/* ============================ 界面导航 ============================ */

// v416：只点游戏内图标离开当前页，绝不注入系统返回键。
// 背包开着点背包 X；图鉴页点图鉴右上返回箭头；其余副页点「→]」返回箭头。
function tapPageBack(why) {
    if (bagOpened()) {
        api.log(why + "：背包开着 → 点背包 X @" + X_CLOSE + "," + Y_CLOSE + "（不按返回键）");
        api.tap(X_CLOSE, Y_CLOSE);
        return;
    }
    if (bookPageOpened()) {
        api.log(why + "：图鉴开着 → 点右上返回箭头 @" + X_BK_CLOSE + "," + Y_BK_CLOSE + "（不按返回键）");
        api.tap(X_BK_CLOSE, Y_BK_CLOSE);
        return;
    }
    api.log(why + "：点副页右上返回箭头 @" + UI_BACK[0] + "," + UI_BACK[1] + "（不按返回键）");
    api.tap(UI_BACK[0], UI_BACK[1]);
}

// 归位到主界面：点取消清弹窗 / 点页面返回图标，最多 2 轮
// v416：整条路径不再按系统返回键（旧版 4 轮 safeBack 已删除）。
function backToGame() {
    for (var i = 0; i < 2; i++) {
        if (api.isOnMainHud()) return true;
        if (dismissDialog()) { api.sleep(900); continue; }
        tapPageBack("归位");
        api.sleep(900);
    }
    if (!api.isOnMainHud()) {
        api.log("归位：仍不在主界面，本轮停手等下一次心跳（不按返回键）");
    }
    return api.isOnMainHud();
}

// 屏幕正中的「取消/确认」框：有就点取消，返回是否点过
function dismissDialog() {
    var dlg = api.ocr(R_DIALOG);
    if (dlg.length === 0) return false;
    var cancel = findWord(dlg, ["取消"]);
    if (!cancel) return false;
    api.log("弹窗盖着屏幕（" + summaryOf(dlg, 4) + "），点「取消」清掉");
    api.tap(cancel.cx, cancel.cy);
    api.sleep(800);
    return true;
}

// 主界面右上角读负重百分比，读不到返回 -1
function weightPct() {
    var regs = [R_WEIGHT, R_WEIGHT_WIDE];
    for (var r = 0; r < regs.length; r++) {
        var items = api.ocrBig(regs[r], OCR_BIG_W);
        for (var i = 0; i < items.length; i++) {
            var t = norm(items[i].text);
            var m = P_PCT.exec(t);
            if (m) {
                var v = parseIntSafe(m[1], -1);
                if (v >= 0 && v <= 100) return v;
            }
        }
    }
    return -1;
}

// 当前屏幕上是不是背包面板
// 画面校验：扫 R_BAG_OPEN，任一 BAG_OPEN_WORDS 命中即判背包开着。
// 无入参；返回 boolean；副作用仅 1 次 OCR。OCR 空/不命中都返回 false（会被当没开）。
function bagOpened() {
    var t = api.ocr(R_BAG_OPEN);
    for (var i = 0; i < t.length; i++) {
        var s = norm(t[i].text);
        for (var w = 0; w < BAG_OPEN_WORDS.length; w++) {
            if (s.indexOf(BAG_OPEN_WORDS[w]) >= 0) return true;
        }
    }
    return false;
}

// 打开背包并验证：OCR 找负重百分比点它，认不出才用标定坐标兜底
function openBag() {
    for (var i = 0; i < RETRY_TAP; i++) {
        // 第 1 轮：直接点标定坐标（1031,32 实测一点就开），不 OCR。
        // 后面几轮才用 OCR 重新找百分比 —— 固定坐标点空说明 HUD 变了，那时再算。
        if (i === 0) {
            api.log("点背包图标 @" + X_BAG_ICON + "," + Y_BAG_ICON + "（标定坐标，不识别）");
            api.tap(X_BAG_ICON, Y_BAG_ICON);
            api.sleep(1800);
            if (bagOpened()) {
                api.log("背包已打开");
                return true;
            }
            api.log("标定坐标没打开背包，改用识别方式重试");
            continue;
        }
        // 先窄框后整条 HUD：图标增减会让百分比左右移，硬编码框迟早失效
        var hit = null;
        var regs = [R_WEIGHT, R_WEIGHT_WIDE];
        for (var r = 0; r < regs.length && !hit; r++) {
            var w = api.ocrBig(regs[r], OCR_BIG_W);
            for (var k = 0; k < w.length; k++) {
                if (w[k].text != null && w[k].text.indexOf("%") >= 0) { hit = w[k]; break; }
            }
        }
        if (hit) {
            // 第 1 轮点图标（文字上方 14px），第 2 轮起点文字本身，都不行才用标定坐标
            var iy = (i === 0) ? (hit.cy - 14) : hit.cy;
            api.log("点负重「" + hit.text + "」@" + hit.cx + "," + iy + " 开背包（第 " + (i + 1) + " 轮）");
            api.tap(hit.cx, iy);
        } else {
            api.log("没认出负重按钮，按标定坐标点 " + X_BAG_ICON + "," + Y_BAG_ICON);
            api.tap(X_BAG_ICON, Y_BAG_ICON);
        }
        api.sleep(2400);
        if (bagOpened()) {
            api.log("背包已打开");
            return true;
        }
        api.log("背包没打开（第 " + (i + 1) + " 次），重试");
        api.sleep(700);
    }
    return false;
}

// 确保背包面板开着（主界面就点负重图标，其余页面点自己的关闭/返回图标归位）
function ensureBag() {
    for (var i = 0; i < 3; i++) {
        if (bagOpened()) return true;
        if (api.isOnMainHud()) return openBag();
        tapPageBack("不在背包界面");
        api.sleep(1000);
    }
    return openBag();
}

// 退出图鉴回背包：最多 3 次「已在背包就成功 → 点图鉴右上返回箭头 + 1100ms」，3 次后交给 ensureBag()。
// 无入参；返回 boolean（ensureBag 的结果）。副作用：点返回箭头、睡眠、可能再开背包。
function exitToBag() {
    for (var i = 0; i < 3; i++) {
        if (bagOpened()) return true;
        api.log("退出图鉴 → 点右上返回箭头 @" + X_BK_CLOSE + "," + Y_BK_CLOSE + "（不按返回键）");
        api.tap(X_BK_CLOSE, Y_BK_CLOSE);
        api.sleep(1100);
    }
    return ensureBag();
}

// 菜单 → 收藏：打开图鉴并校验；失败重试
function openCollection() {
    for (var i = 1; i <= RETRY_TAP; i++) {
        // 背包/详情开着会挡住「菜单」按钮，先点背包 X 关掉
        if (bagOpened()) {
            api.log("背包开着挡菜单 → 点背包 X @" + X_CLOSE + "," + Y_CLOSE + "（不按返回键）");
            api.tap(X_CLOSE, Y_CLOSE);
            api.sleep(1000);
        }
        // ★ 2026-11-03 改法（用户要求：别再每次重新算坐标）：
        //   「菜单」「收藏」这两处位置是死的 —— 实测 bbox 跨上百张截图没挪过，
        //   所以第 1 轮**直接点标定坐标，一次 OCR 都不做**（省 1~3 秒，也不会算出歪的落点）。
        //   只有画面校验没通过（真点空了）才退到第 2 轮用 OCR 重新找位置 ——
        //   「固定坐标 + 结果校验 + 失败才识别」比「每次先识别再点」又快又稳。
        var useOcr = (i > 1);
        var mx = X_MENU, my = Y_MENU;
        if (useOcr) {
            var top = api.ocrBig([88, 2, 12, 11], 320);
            var mw = findWord(top, MENU_WORDS);
            if (mw) {
                mx = mw.cx;
                my = mw.cy;
            } else {
                api.log("第二轮：顶部还是认不出「菜单」，继续用标定坐标");
            }
        }
        api.log("点「菜单」@" + mx + "," + my + (useOcr ? "（OCR 纠正）" : "（标定坐标）"));
        api.tap(mx, my);
        api.sleep(WAIT_PAGE);

        var spots = [[X_BOOK_ICON, Y_BOOK_ICON], [X_BOOK_ICON, Y_BOOK_ICON + 30]];
        if (useOcr) {
            var full = api.ocr(null);
            var fav = findWord(full, BOOK_ENTRY_WORDS);
            if (fav) {
                spots.push([fav.cx, fav.cy - 30]);
                spots.push([fav.cx, fav.cy]);
            } else {
                api.log("第二轮：菜单里认不出「收藏」（" + summaryOf(full, 6) + "），继续按标定坐标点");
            }
        }
        for (var t = 0; t < spots.length; t++) {
            api.log("点「收藏」@" + spots[t][0] + "," + spots[t][1] + " 开图鉴（位置 " + (t + 1) + "/" + spots.length + "）");
            api.tap(spots[t][0], spots[t][1]);
            api.sleep(t === 0 ? WAIT_PAGE : 1400);
            if (bookOpened()) {
                api.log("图鉴已打开");
                return true;
            }
        }
        api.log("点完「收藏」图鉴没开（第 " + i + " 次），重试");
    }
    return false;
}

// 图鉴开着的画面校验：分页词或「图鉴」字样出现
function bookOpened() {
    var all = api.ocr(null);
    return findWord(all, BOOK_OPEN_WORDS) != null;
}

/* ============================ 分页遍历 ============================ */

// 全屏 OCR 找分页签：取「同排且词表命中数最多」的一行
function findTabs() {
    var all = api.ocr(null);
    var hits = [];
    for (var i = 0; i < all.length; i++) {
        if (matchPageWord(norm(all[i].text)) != null) hits.push(all[i]);
    }
    if (hits.length === 0) return hits;
    // 按行聚类（cy 差 < 屏高 6%），取块数最多的那行
    var rowGap = Math.max(1, api.screenH() * 6 / 100);
    var rows = [];
    for (var j = 0; j < hits.length; j++) {
        var row = null;
        for (var r = 0; r < rows.length; r++) {
            if (Math.abs(rows[r][0].cy - hits[j].cy) < rowGap) { row = rows[r]; break; }
        }
        if (!row) { row = []; rows.push(row); }
        row.push(hits[j]);
    }
    var best = rows[0];
    for (var r2 = 1; r2 < rows.length; r2++) {
        if (rows[r2].length > best.length) best = rows[r2];
    }
    best.sort(function (a, b) { return a.cx - b.cx; });
    tabRowPct = best[0].cy * 100 / api.screenH();
    api.log("分页签：" + summaryOf(best, 8));
    return best;
}

// 点某个分页签（重扫定位，不用旧坐标）
function tapPageTab(page) {
    var tabs = findTabs();
    for (var i = 0; i < tabs.length; i++) {
        if (page === matchPageWord(norm(tabs[i].text))) {
            api.tap(tabs[i].cx, tabs[i].cy);
            api.sleep(WAIT_PAGE);
            return;
        }
    }
    api.log("重找分页签「" + page + "」失败，不点（不赌坐标）");
}

// 分页内容区：分页签行以下到屏幕 86%
function pageRegion() {
    var top = tabRowPct < 0 ? 12 : Math.min(80, tabRowPct + 4);
    return [2, top, 98, 86];
}

// 遍历全部分页，收集所有「亮」列
function scanAllPages() {
    var all = [];
    var tabs = findTabs();
    if (tabs.length === 0) {
        api.log("图鉴里认不出任何分页签（词表：普通/高级/稀有/史诗/传说…），中止分页扫描");
        api.event("图鉴分页认不出，中止");
        return all;
    }
    var visited = {};
    var prevSnap = null;
    for (var i = 0; i < tabs.length && Object.keys(visited).length < MAX_PAGES; i++) {
        var tab = tabs[i];
        var page = matchPageWord(norm(tab.text));
        if (page == null || visited[page]) continue;
        api.log("切到分页「" + page + "」@" + tab.cx + "," + tab.cy);
        api.tap(tab.cx, tab.cy);
        api.sleep(WAIT_PAGE);
        var blocks = api.ocr(pageRegion());
        var snap = snapshot(blocks);
        // 画面校验：和上一页内容一样 → 可能没切过去，重试一次
        if (prevSnap != null && snap === prevSnap) {
            api.log("分页「" + page + "」内容与上一页相同，可能没切过去，重试一次");
            api.tap(tab.cx, tab.cy);
            api.sleep(WAIT_PAGE);
            blocks = api.ocr(pageRegion());
            snap = snapshot(blocks);
            if (snap === prevSnap) {
                api.log("重试后仍无变化，按当前画面继续（可能这页本来就是空的）");
            }
        }
        visited[page] = true;
        prevSnap = snap;

        var cols = collectColumns(page, blocks);
        var todo = 0;
        for (var c = 0; c < cols.length; c++) {
            // ★ 2026-11-03 实拍纠正：图鉴里「橙勾 = 已收藏」，已收藏那块是亮的（亮度 6~8%）；
            // 「未收藏」是暗的灰格（亮度 2~3%）。原代码把「亮」当可收藏 → 方向反了，
            // 等于每次都去点已经收掉的条目，一件也收不进来。这里改成收「暗」的。
            if (!cols[c].bright) {
                todo++;
                if (all.length < MAX_SLOTS_PER_PAGE * MAX_PAGES) all.push(cols[c]);
            }
        }
        api.log("分页「" + page + "」：未收藏（暗）" + todo + " / 列 " + cols.length);
    }
    return all;
}

/* ============================ 列识别 / 亮暗 ============================ */

// 从一页 OCR 结果里聚出所有「列」并判亮暗
function collectColumns(page, blocks) {
    var out = [];
    var reqs = [];
    for (var i = 0; i < blocks.length; i++) {
        if (parseReq(blocks[i].text) != null) reqs.push(blocks[i]);
    }
    if (reqs.length === 0) {
        api.log("分页「" + page + "」没认出任何「+N」收藏条目"
            + (blocks.length === 0 ? "（整页 OCR 空）" : "（认出 " + blocks.length + " 块其它文字）"));
        return out;
    }
    reqs.sort(function (a, b) { return a.cx - b.cx; });
    // 聚类
    var clusters = [];
    for (var j = 0; j < reqs.length; j++) {
        var cl = null;
        for (var k = 0; k < clusters.length; k++) {
            var last = clusters[k][clusters[k].length - 1];
            if (Math.abs(reqs[j].cx - last.cx) <= COL_GAP_PX) { cl = clusters[k]; break; }
        }
        if (!cl) { cl = []; clusters.push(cl); }
        cl.push(reqs[j]);
    }
    for (var c = 0; c < clusters.length; c++) {
        var col = { page: page, name: "", reqs: [], bright: false };
        var l = 999999, t = 999999, r = 0, b = 0, cxSum = 0;
        var lvSet = {};
        for (var m = 0; m < clusters[c].length; m++) {
            var it = clusters[c][m];
            if (it.l < l) l = it.l;
            if (it.t < t) t = it.t;
            if (it.r > r) r = it.r;
            if (it.b > b) b = it.b;
            cxSum += it.cx;
            var lv = parseReq(it.text);
            if (lv != null) lvSet[lv] = true;
        }
        col.cx = Math.round(cxSum / clusters[c].length);
        col.l = Math.max(0, l - COL_PAD_PX);
        col.t = Math.max(0, t - COL_PAD_PX);
        col.r = r + COL_PAD_PX;
        col.b = b + COL_PAD_PX;
        for (var lvKey in lvSet) col.reqs.push(parseIntSafe(lvKey, 0));
        col.reqs.sort(function (a, b2) { return a - b2; });
        col.name = findName(blocks, col);
        var ratio = api.brightRatio([col.l * 100 / api.screenW(), col.t * 100 / api.screenH(),
                                     col.r * 100 / api.screenW(), col.b * 100 / api.screenH()],
                                    BRIGHT_MIN_LUMA);
        col.bright = ratio >= BRIGHT_MIN_RATIO;
        api.log("列[" + page + "] x≈" + col.cx + " 名=「" + col.name + "」 req=" + col.reqs
            + " 亮暗比=" + ratio + "% → " + (col.bright ? "亮" : "暗（已收藏）"));
        out.push(col);
    }
    return out;
}

// 列上方最近的非数字文本块当装备名（150px 内），没有就空串
function findName(blocks, col) {
    var best = null;
    for (var i = 0; i < blocks.length; i++) {
        var it = blocks[i];
        if (it.cx < col.l + COL_PAD_PX / 2 || it.cx > col.r - COL_PAD_PX / 2) continue;
        if (parseReq(it.text) != null) continue;      // 条目本身不算名字
        if (it.cy >= col.t + COL_PAD_PX) continue;    // 只看列框以上/框沿
        if (norm(it.text).length < 2) continue;
        if (!best || it.cy > best.cy) best = it;      // 离列最近（最靠下）的
    }
    return best ? norm(best.text) : "";
}

// 重新在当前页 OCR 结果里定位这列（按名字或 x 中心）；找不到返回 null
function relocateCol(blocks, orig, name) {
    var cols = collectColumns(orig.page, blocks);
    for (var i = 0; i < cols.length; i++) {
        if (name.length > 0 && cols[i].name.length > 0 && sameItem(cols[i].name, name)) return cols[i];
    }
    for (var j = 0; j < cols.length; j++) {
        if (Math.abs(cols[j].cx - orig.cx) <= COL_GAP_PX) return cols[j];
    }
    return null;
}

// 在列框里找文本为「+target」的收藏条目块
function findEntry(blocks, col, target) {
    var best = null;
    for (var i = 0; i < blocks.length; i++) {
        var it = blocks[i];
        if (it.cx < col.l || it.cx > col.r) continue;
        var lv = parseReq(it.text);
        if (lv == null || lv !== target) continue;
        if (!best || Math.abs(it.cx - col.cx) < Math.abs(best.cx - col.cx)) best = it;
    }
    return best;
}

/* ============================ 背包扫描 ============================ */

// 逐格扫背包：名字 / 类型 / 品级 / 当前强化等级。空格直接跳过
function scanInventory() {
    var out = [];
    for (var r = 0; r < GY.length; r++) {
        for (var c = 0; c < GX.length; c++) {
            setState("扫背包 " + (r + 1) + "-" + (c + 1));
            var it = probeGrid(r, c);
            if (it) out.push(it);
        }
    }
    api.log("背包扫出 " + out.length + " 件装备");
    for (var i = 0; i < out.length; i++) {
        var it2 = out[i];
        api.log("  「" + it2.name + "」"
            + (it2.typeKnown ? (it2.weapon ? "武器" : "防具") : "类型?")
            + (it2.precious ? it2.grade + "装(不动)" : "")
            + " +" + it2.level + " @" + it2.gridR + "-" + it2.gridC);
    }
    return out;
}

// 探一个背包格子：点格子 → 详情 → 读名字/类型/品级。空格子返回 null
function probeGrid(r, c) {
    api.tap(GX[c], GY[r]);
    api.sleep(700);
    api.tap(X_INFO, Y_INFO);
    api.sleep(1300);
    var name = readDetailName();
    // 不是装备名的垃圾读数（「:」「0020/200」「0000」）直接跳过，
    // 否则会被当成「类型认不出」白扫一遍还占时间
    if (name.length < 2 || /^[\d\s:./%()（）-]+$/.test(name)) {
        closeDetail();
        return null;
    }
    var it = {
        name: name, gridR: r, gridC: c,
        weapon: false, typeKnown: false, precious: false,
        level: 0, grade: api.gradeOf(R_NAME)
    };
    // v2.1.0：api.gradeOf 返回可能是 Java String，=== 永远 false 会把紫/红装放过 → 危险。
    // 先拼成 JS 字符串再比。
    it.precious = ("" + it.grade) === "紫" || ("" + it.grade) === "红";
    fillType(it);
    var lv = parseLevel(name);
    it.level = lv == null ? 0 : lv;
    closeDetail();
    return it;
}

// 从详情面板整体文本里认装备类型；认不出就 typeKnown=false（保守跳过）
function fillType(it) {
    var txt = api.ocr(R_DETAIL);
    var weapon = false, armor = false;
    for (var i = 0; i < txt.length; i++) {
        var s = norm(txt[i].text);
        if (s.indexOf("武器") >= 0) weapon = true;
        if (s.indexOf("防具") >= 0 || s.indexOf("护甲") >= 0 || s.indexOf("盔") >= 0 || s.indexOf("靴") >= 0) armor = true;
        if (s.indexOf("攻击力") >= 0) weapon = true;
        if (s.indexOf("防御力") >= 0) armor = true;
    }
    if (weapon && !armor) {
        it.weapon = true; it.typeKnown = true;
    } else if (armor && !weapon) {
        it.weapon = false; it.typeKnown = true;
    } else {
        it.typeKnown = false;
        api.log("「" + it.name + "」类型认不出（武器/防具/攻防词都没对上），后面按跳过处理");
    }
}

// 读详情面板顶部装备名（小字，ocrBig 放大认）；读不到返回空串
function readDetailName() {
    var nm = api.ocrBig(R_NAME, OCR_BIG_W);
    if (nm.length === 0) nm = api.ocr(R_NAME);   // 放大认不出时退普通扫再试一次
    return nm.length === 0 ? "" : norm(nm[0].text);
}

// 详情开着时读装备名尾部等级（读不到返回 -1）
function readDetailLevel() {
    var lv = parseLevel(readDetailName());
    return lv == null ? -1 : lv;
}

// 详情面板开着、且顶部名字和期望一致（防详情实际没开/开成别的格子）
function openDetail(r, c, expectName) {
    for (var i = 0; i < RETRY_TAP; i++) {
        api.tap(GX[c], GY[r]);
        api.sleep(700);
        api.tap(X_INFO, Y_INFO);
        api.sleep(1300);
        var nm = readDetailName();
        if (nm.length > 0 && sameItem(nm, expectName)) return true;
        api.log("详情名字对不上（读到「" + nm + "」期望「" + expectName + "」，第 " + (i + 1) + " 次）");
        closeDetail();
    }
    return false;
}

// 在背包里按名字找装备：先按上一轮记录的格子直接验（快），不中再全包扫
function findInBag(name) {
    for (var i = 0; i < lastInv.length; i++) {
        var cached = lastInv[i];
        if (!sameItem(cached.name, name)) continue;
        var got = probeGrid(cached.gridR, cached.gridC);
        if (got && sameItem(got.name, name)) return got;
        break;   // 记录的格子对不上就别再试了，走全包扫
    }
    var inv = scanInventory();
    lastInv = inv;
    for (var j = 0; j < inv.length; j++) {
        if (sameItem(inv[j].name, name)) return inv[j];
    }
    return null;
}

// 关详情面板：点右上 X(1223,95) 后等 700ms。无返回值，不校验是否真关掉。
function closeDetail() {
    api.tap(X_CLOSE, Y_CLOSE);
    api.sleep(700);
}

/* ============================ 阶段A：决策 ============================ */

// 逐列决策并打结构化日志：装备名、分页、req_levels、上限、决策及原因
function decide(cols, inv, ctasks, dtasks) {
    var seen = {};   // 幂等：同一件装备一轮只建一个任务
    var bright = 0;
    for (var i = 0; i < cols.length; i++) {
        var c = cols[i];
        if (c.bright) continue;   // 亮的 = 已收藏，跳过（scanAllPages 已过滤，双保险）
        bright++;
        var item = c.name.length > 0 ? matchItem(inv, c.name) : null;
        var reqStr = "[" + c.reqs.join(",") + "]";
        if (!item) {
            api.log("列[" + c.page + "] 名=「" + c.name + "」 req=" + reqStr
                + " → 跳过（装备名对不上背包/读不到名，不能盲收藏更不能盲分解）");
            continue;
        }
        if (item.precious) {
            api.log("列[" + c.page + "] 名=「" + item.name + "」(" + item.grade + "装) req=" + reqStr
                + " → 跳过（紫/红装不收藏不分解）");
            continue;
        }
        if (!item.typeKnown) {
            api.log("列[" + c.page + "] 名=「" + item.name + "」 req=" + reqStr
                + " → 跳过（武器/防具类型认不出，安全上限定不了）");
            continue;
        }
        var cap = item.weapon ? CAP_WEAPON : CAP_ARMOR;
        var best = null;
        for (var j = 0; j < c.reqs.length; j++) {
            if (c.reqs[j] <= cap && (best == null || c.reqs[j] < best)) best = c.reqs[j];
        }
        if (best != null) {
            api.log("列[" + c.page + "] 名=「" + item.name + "」(" + (item.weapon ? "武器" : "防具")
                + " 上限+" + cap + ") req=" + reqStr + " → 收藏到 +" + best
                + "（当前 +" + item.level + "）");
            var t = { col: c, target: best, item: item };
            // 同名装备出现多列时保留要求最低的一条
            var old = findTask(ctasks, item.name);
            if (!old) ctasks.push(t);
            else if (t.target < old.target) ctasks[ctasks.indexOf(old)] = t;
        } else {
            var minReq = null;
            for (var k = 0; k < c.reqs.length; k++) {
                if (minReq == null || c.reqs[k] < minReq) minReq = c.reqs[k];
            }
            api.log("列[" + c.page + "] 名=「" + item.name + "」(" + (item.weapon ? "武器" : "防具")
                + " 上限+" + cap + ") req=" + reqStr + " → 分解（最低要求 +"
                + minReq + " 超过安全上限 +" + cap + "）");
            var d = { item: item, minReq: minReq == null ? -1 : minReq, page: c.page };
            if (!seen[baseName(item.name)]) { dtasks.push(d); seen[baseName(item.name)] = true; }
        }
    }
    api.log("亮列 " + bright + " 个 → 收藏任务 " + ctasks.length + "、分解任务 " + dtasks.length);
}

// 在收藏任务列表里按「同名装备」找已有任务（sameItem 容错比较）。
// 入参 list=ctasks、name=装备名；返回任务对象或 null。无副作用。
function findTask(list, name) {
    for (var i = 0; i < list.length; i++) {
        if (sameItem(list[i].item.name, name)) return list[i];
    }
    return null;
}

/* ============================ 阶段B：收藏 ============================ */

// 执行一条收藏任务：背包确认 → 强化到目标档 → 图鉴点条目 → 等列变暗
function doCollectTask(t, idx, total) {
    setState("收藏 " + (idx + 1) + "/" + total + "：" + t.item.name + " → +" + t.target);
    if (!exitToBag()) {
        api.log("回不到背包，跳过「" + t.item.name + "」的收藏");
        return false;
    }
    var it = findInBag(t.item.name);
    if (!it) {
        api.log("背包里找不到「" + t.item.name + "」，跳过（可能已经收掉了）");
        return false;
    }
    if (it.level < t.target && !enhanceTo(it, t.target)) {
        api.log("「" + t.item.name + "」强化到 +" + t.target + " 失败，跳过收藏（不进分解列表，留给下一轮）");
        return false;
    }
    if (!openCollection()) {
        api.log("图鉴打不开，跳过「" + t.item.name + "」的收藏");
        return false;
    }
    var ok = collectEntry(t);
    if (ok) api.event("收藏成功：" + t.item.name + " → +" + t.target);
    return ok;
}

// 在图鉴里定位目标列 → 点「+target」条目 → 确认 → 以「列由亮变暗」为唯一判据
function collectEntry(t) {
    for (var attempt = 1; attempt <= RETRY_COLLECT; attempt++) {
        var blocks = api.ocr(pageRegion());
        var now = relocateCol(blocks, t.col, t.item.name);
        if (now && !now.bright) {
            api.log("「" + t.item.name + "」所在列已是暗的（之前收掉了），幂等成功");
            return true;
        }
        if (!now) {
            api.log("图鉴里找不到「" + t.item.name + "」的列（第 " + attempt + " 次），重切分页重试");
            tapPageTab(t.col.page);
            continue;
        }
        var entry = findEntry(blocks, now, t.target);
        if (!entry) {
            api.log("列里认不出 +" + t.target + " 条目（" + summaryOf(blocks, 5) + "），重试");
            tapPageTab(t.col.page);
            continue;
        }
        api.log("点收藏条目「" + entry.text + "」@" + entry.cx + "," + entry.cy);
        api.tap(entry.cx, entry.cy);
        api.sleep(WAIT_UI);
        // 弹确认框就点「确定/确认」（词表里没有「收藏」，正文里那句话匹配不上）
        confirmOk("收藏");
        // 唯一成功判据：该列由亮变暗
        if (waitDimmed(now)) {
            api.log("列已由亮变暗 → 收藏成功「" + t.item.name + "」+" + t.target);
            return true;
        }
        api.log("收藏后列仍亮（第 " + attempt + " 次），重试");
    }
    api.log("收藏最终失败：「" + t.item.name + "」，跳过该列");
    return false;
}

// 轮询等该列变暗；超时返回 false。
// 审计裁决：保持「列找不到也算成功」的幂等语义（与原生 CollectionModule 同款），
// 但两条成功路径必须区分日志 —— 以后排查「OCR 抖动把亮列认没了导致假成功」有据可查。
function waitDimmed(col) {
    var deadline = Date.now() + SLOT_DIM_TIMEOUT;
    while (Date.now() < deadline) {
        api.sleep(DIM_POLL_GAP);
        var blocks = api.ocr(pageRegion());
        var now = relocateCol(blocks, col, col.name);
        if (now && !now.bright) {
            api.log("确认变暗：列已由亮变暗（可靠成功判据）");
            return true;
        }
        if (!now) {
            api.log("列找不到（按幂等成功处理；注意：也可能是 OCR 抖动把列认没了，必要时人工复查）");
            return true;
        }
    }
    return false;
}

// 逐级强化：从当前等级到 target，绝不越过安全上限；失败返回 false
function enhanceTo(it, target) {
    var cap = it.weapon ? CAP_WEAPON : CAP_ARMOR;
    if (target > cap) {
        api.log("拒绝强化：「" + it.name + "」目标 +" + target + " 超过安全上限 +" + cap);
        return false;
    }
    if (!openDetail(it.gridR, it.gridC, it.name)) {
        api.log("「" + it.name + "」详情打不开，没法强化");
        return false;
    }
    var fails = 0, steps = 0;
    while (it.level < target && steps++ < ENHANCE_MAX_STEPS) {
        if (it.level + 1 > cap) {
            api.log("已到安全上限 +" + cap + "，停止强化（保险丝，正常走不到这）");
            break;
        }
        setState("强化「" + baseName(it.name) + "」+" + (it.level + 1) + "（上限 +" + cap + "）");
        // OCR 找「强化」，只在详情底部按钮排找（属性文本里的「强化」不算）
        var btns = api.ocr(R_DETAIL_BTN);
        var btn = null;
        for (var i = 0; i < btns.length; i++) {
            if (btns[i].cy < api.screenH() * 0.75) continue;
            if (norm(btns[i].text).indexOf("强化") >= 0) { btn = btns[i]; break; }
        }
        if (btn) {
            api.log("点「强化」@" + btn.cx + "," + btn.cy + "（当前 +" + it.level + "）");
            api.tap(btn.cx, btn.cy);
        } else {
            api.log("底部认不出「强化」（" + summaryOf(btns, 4) + "），按候选坐标点 "
                + X_ENH_CAND + "," + Y_ENH_CAND);
            api.tap(X_ENH_CAND, Y_ENH_CAND);
        }
        api.sleep(WAIT_ENHANCE);
        var lv = readDetailLevel();
        if (lv === it.level + 1) {
            it.level = lv; fails = 0;
            api.log("强化成功 → +" + lv);
        } else if (lv === it.level) {
            fails++;
            api.log("强化没生效（还是 +" + it.level + "，第 " + fails + " 次，材料不足/次数用尽?）");
            if (fails >= ENHANCE_RETRY) break;
        } else if (lv > 0) {
            api.log("等级读数 " + it.level + " → " + lv + "，采信新值");
            it.level = lv;
            if (lv > target) break;
        } else {
            fails++;
            api.log("读不到当前强化等级，重试");
            if (fails >= ENHANCE_RETRY + 1) break;
        }
    }
    closeDetail();
    if (it.level >= target) {
        api.event("强化完成：" + baseName(it.name) + " → +" + it.level);
        return true;
    }
    return false;
}

/* ============================ 阶段C：分解 ============================ */

// 分解一件：背包定位 → 长按 → 分解 → 确认 → 以「装备从背包消失」为唯一判据
function doDecompose(d, idx, total) {
    setState("分解 " + (idx + 1) + "/" + total + "：" + d.item.name);
    var it = findInBag(d.item.name);
    if (!it) {
        api.log("背包里没有「" + d.item.name + "」（已处理掉了），按幂等成功");
        return true;
    }
    for (var attempt = 1; attempt <= RETRY_TAP; attempt++) {
        var gx = GX[it.gridC], gy = GY[it.gridR];
        api.log("长按「" + baseName(d.item.name) + "」@" + gx + "," + gy + "（第 " + attempt + " 次）");
        if (!api.longPress(gx, gy, LONG_PRESS_MS)) {
            api.log("长按派发失败，重试");
            continue;
        }
        api.sleep(WAIT_UI);
        // 长按后：要么直接弹分解确认框，要么出一个小菜单带「分解」。全屏 OCR 找。
        var hits = api.ocr(null);
        var brk = null;
        for (var i = 0; i < hits.length; i++) {
            if (hits[i].cy < api.screenH() * 0.55) continue;   // 分解入口在下半屏
            if (norm(hits[i].text).indexOf("分解") >= 0) { brk = hits[i]; break; }
        }
        if (brk) {
            api.log("长按出菜单，点「分解」@" + brk.cx + "," + brk.cy);
            api.tap(brk.cx, brk.cy);
            api.sleep(WAIT_UI);
        } else {
            // 兜底：详情面板底部那颗「分解」（固定坐标，灰字 OCR 认不出但位置不变）
            api.log("长按没认出「分解」（" + summaryOf(hits, 5) + "），走详情面板兜底");
            if (!openDetail(it.gridR, it.gridC, d.item.name)) {
                api.log("详情也打不开，重试");
                continue;
            }
            api.tap(X_BREAK, Y_BREAK);
            api.sleep(WAIT_UI);
        }
        // 确认框（词表只有 确定/确认；正文若写「分解后该道具将消失」不会被误点）
        if (!confirmOk("分解")) {
            api.log("没弹确认框或没点掉（第 " + attempt + " 次），重试");
            continue;
        }
        // 唯一成功判据：装备从背包消失
        if (goneFromBag(it, d.item.name)) {
            api.log("「" + d.item.name + "」已从背包消失 → 分解成功");
            api.event("分解成功：" + d.item.name + "（req+" + d.minReq + " 超上限，" + d.page + "页）");
            return true;
        }
        api.log("分解后装备还在背包（第 " + attempt + " 次），重试");
    }
    api.log("分解最终失败：「" + d.item.name + "」，记录后继续下一件");
    api.event("分解失败：" + d.item.name);
    return false;
}

// 校验该装备已从背包消失：回探原格子，详情里认不出同名装备 = 消失
function goneFromBag(it, name) {
    api.sleep(1200);   // 给背包刷新留时间
    var got = probeGrid(it.gridR, it.gridC);
    if (!got) return true;              // 格子空了
    return !sameItem(got.name, name);   // 换了别的装备 = 消失了
}

/* ============================ 确认框 ============================ */

// 弹确认框就点「确定/确认」并验证弹窗真的没了（词表无泛词、认不出按钮不盲点）
function confirmOk(what) {
    var dlg = api.ocr(R_DIALOG);
    if (dlg.length === 0) return false;

    // 用实际扫到的文字块算弹窗上下边界，按钮在下面 45% 里，正文在上面
    var top = 999999, bot = 0;
    for (var i = 0; i < dlg.length; i++) {
        if (dlg[i].t < top) top = dlg[i].t;
        if (dlg[i].b > bot) bot = dlg[i].b;
    }
    var cut = top + (bot - top) * 55 / 100;

    var ok = null;
    for (var j = 0; j < dlg.length && !ok; j++) {
        if (dlg[j].cy < cut) continue;   // 正文区，跳过
        var s = norm(dlg[j].text);
        for (var w = 0; w < OK_WORDS.length; w++) {
            if (s.indexOf(OK_WORDS[w]) >= 0) { ok = dlg[j]; break; }
        }
    }
    if (!ok) {
        // 教训：认不出按钮就记日志放弃，绝不盲点角落
        api.log(what + "确认框没认出按钮（" + summaryOf(dlg, 6) + "），不盲点，放弃这次");
        return false;
    }
    api.log(what + "确认框点「" + ok.text + "」@" + ok.cx + "," + ok.cy);
    api.tap(ok.cx, ok.cy);
    api.sleep(1500);

    // 验证：弹窗真的没了才算点掉
    var after = api.ocr(R_DIALOG);
    if (after.length > 0) {
        api.log(what + "点完弹窗还在（" + summaryOf(after, 4) + "）→ 不算成功");
        var cancel2 = findWord(after, ["取消"]);
        if (cancel2) {
            api.log(what + "→ 点「取消」收掉弹窗（不按返回键）");
            api.tap(cancel2.cx, cancel2.cy);
        } else {
            api.log(what + "→ 认不出「取消」，放弃这次（不按返回键）");
        }
        api.sleep(700);
        return false;
    }
    return true;
}

/* ============================ 主流程 ============================ */

// 2026-11-03 实拍：背包左侧竖排页签 全部/装备/道具/材料，
// 「装备」在第 2 项（原图 914,239）。背包默认是「全部」，里面混着材料、卷轴、
// 药水 —— 那些在详情里认不出武器/防具，会白扫一遍还耽误时间。
function switchEquipTab() {
    // 2026-11-03 实拍（2 倍放大量）：背包左侧竖排 全部/装备/道具/材料，
    // 「装备」图标中心 ≈ (902,225)，文字在它下方 ≈ (902,258)。
    // 上一版点 (914,239) 差 30~40px，落在两个页签之间 → 没切过去，
    // 结果扫了一堆「庆典神书/神谕之书」这类道具，白跑 3 分钟。
    api.log("切到「装备」页签 @902,225");
    api.tap(902, 225);
    api.sleep(900);
    api.tap(902, 258);   // 图标没点上就点文字，两个都点不影响结果（同一个页签）
    api.sleep(1200);
}

/**
 * 2026-11-03 实测结论：图鉴那条路走不通 —— 图鉴条目名是**收藏主题**
 * （「普通的开始」「奇岩特产品」「精灵族的坚强意志」），背包里是**单件装备名**
 * （「卡勒米安外衣」「腰带」「魔珠」），两套命名永远匹配不上，所以 decide() 100% 跳过。
 * 真正能用的是背包详情面板底部那个「收藏」按钮：选中装备 → 点收藏 → 游戏自己判断
 * 能不能收（不满足条件会提示），收掉后装备消失、负重立刻下降。
 * 判据就用负重下降（用户 11-02 确认过：负重下降才算真收藏）。
 */
function collectInBag() {
    var w0 = weightPct();
    api.log("按详情「收藏」清背包，当前负重 " + w0 + "%");
    var done = 0, tried = 0;
    for (var r = 0; r < GY.length; r++) {
        for (var c = 0; c < GX.length; c++) {
            setState("收藏 " + (r + 1) + "-" + (c + 1));
            api.tap(GX[c], GY[r]);
            api.sleep(700);
            // 「详情」按钮实测固定在 1061,576（find 一次要 3~6 秒，20 格就多花 2 分钟）
            api.tap(X_INFO, Y_INFO);
            api.sleep(1500);
            var name = readDetailName();
            if (name == null || name.length < 2 || /^[\d\s:./%()（）-]+$/.test(name)) {
                closeDetail();
                continue;
            }
            tried++;
            // 「收藏」按钮实测在 1053,518（第一排第 2 个）。先硬点，认不到确认框再 OCR 找一次
            api.log("「" + name + "」点「收藏」@" + X_FAV + "," + Y_FAV);
            api.tap(X_FAV, Y_FAV);
            api.sleep(1100);
            var okBtn = api.find("确定", R_DIALOG);
            if (okBtn == null) okBtn = api.find("确认", R_DIALOG);
            if (okBtn) {
                api.log("确认框 → 点「" + okBtn.text + "」@" + okBtn.cx + "," + okBtn.cy);
                api.tap(okBtn.cx, okBtn.cy);
                api.sleep(1600);
            }
            closeDetail();
        }
    }
    // 判据只能在这时候读：详情/背包面板会把右上角负重挡死，格子循环里读到的都是 -1
    backToGame();
    var wEnd = weightPct();
    if (w0 >= 0 && wEnd >= 0 && wEnd < w0) {
        done = wEnd < w0 ? 1 : 0;
        api.log("✅ 负重下降 " + w0 + "% → " + wEnd + "%（收藏生效）");
        api.event("收藏生效：负重 " + w0 + "% → " + wEnd + "%");
    } else {
        api.log("本轮负重没有下降（" + w0 + "% → " + wEnd + "%）");
    }
    api.log("本轮收藏完成 " + done + " 件（试过 " + tried + " 件）");
    api.event("收藏本轮结果：" + done + " 件");
    setState(done > 0 ? "已收藏 " + done + " 件" : "这轮没收到");
    backToGame();
    return done > 0;
}

/* ==================== 图鉴登记（v2 真机标定 2026-11-04） ==================== */
// 旧「详情→收藏」路径的故障：游戏判断该件不能直接收时，会把画面切到「道具收藏」图鉴页；
// 脚本却仍按详情面板的 X(1223,95) 去关，页一直留在屏幕上（现场 02261 03:32 截图）。
// v2 按需求文档 §8 走图鉴路线：菜单→收藏→页签→套装行→点图标→「登记」→确认，
// 判据只认「完成道具收藏书签」横幅或该行进度 x 变大；没有可点「登记」的件直接跳过。

var X_BK_MENU = 1205, Y_BK_MENU = 56;      // 主界面右上「菜单」
var X_BK_ENTRY = 1191, Y_BK_ENTRY = 130;   // 菜单面板里的「收藏」入口
var BK_ROW_Y0 = 198, BK_ROW_PITCH = 92, BK_ROWS = 5;   // 套装行：首行 y=198，行距 92
var BK_ICON_X_RIGHT = 705, BK_ICON_PITCH = 74;          // 行内图标右对齐，间距 74
var R_BK_TOP = [2, 0, 100, 18];            // 标题「道具收藏」+ 顶部页签
var R_BK_TABS = [2, 6, 62, 18];
var R_BK_REG = [67, 87, 100, 98];          // 右侧详情底部按钮条（登记/强化/替换）
var R_BK_BANNER = [25, 8, 75, 30];         // 中央「完成道具收藏书签」横幅
var BK_TABS = ["普通", "高级", "稀有", "英雄"];
var BK_REG_WORDS = ["登记", "登录"];       // OCR 常把「登记」认成「登录」

// 顶部页签坐标缓存：切 4 个页只扫一次顶部
var bookTabSpots = null;

// 认「道具收藏」页：标题命中，或页签命中 ≥2 个（只扫一次顶部，避免两遍 OCR）
function bookPageOpened() {
    var top = api.ocr(R_BK_TOP);
    var tabs = 0;
    for (var i = 0; i < top.length; i++) {
        var s = norm(top[i].text);
        if (s.indexOf("道具收藏") >= 0) return true;
        for (var j = 0; j < BK_TABS.length; j++) {
            if (s.indexOf(BK_TABS[j]) >= 0) { tabs++; break; }
        }
    }
    return tabs >= 2;
}

// 菜单→收藏 打开图鉴。标定坐标优先（实测菜单 1205,56 / 收藏 1191,130），
// 连点 3 次（第一次常只选中）；全失败才用 OCR 兜底。
function openBook() {
    if (bookPageOpened()) return true;
    for (var i = 0; i < 3; i++) {
        if (bagOpened()) {
            api.log("背包开着挡菜单 → 点背包 X @" + X_CLOSE + "," + Y_CLOSE + "（不按返回键）");
            api.tap(X_CLOSE, Y_CLOSE);
            api.sleep(900);
        }
        api.tap(X_BK_MENU, Y_BK_MENU);
        api.sleep(1300);
        for (var k = 1; k <= 3; k++) {
            api.tap(X_BK_ENTRY, Y_BK_ENTRY);
            api.sleep(1900);
            if (bookPageOpened()) {
                api.log("已进入「道具收藏」页（第 " + k + " 次点收藏）");
                return true;
            }
        }
    }
    api.log("标定坐标没进图鉴，改用 OCR 找菜单/收藏兜底");
    return openCollection() && bookPageOpened();
}

// 读一行左侧文字（套装名 + 效果 + 进度 x/y）；y 是屏幕像素
function bookRowText(y) {
    var h = Math.max(1, api.screenH());
    var t = Math.max(0, (y - 46) * 100 / h);
    var b = Math.min(100, (y + 46) * 100 / h);
    var items = api.ocr([2, t, 62, b]);
    var sb = [];
    for (var i = 0; i < items.length; i++) sb.push(String(items[i].text));
    return sb.join(" ");
}

// 从整行文字抠「0/3」进度；读不到返回 null
function parseBookProgress(row) {
    if (row == null) return null;
    var m = /(\d{1,2})\/(\d{1,2})/.exec(norm(row));
    if (!m) return null;
    var a = parseIntSafe(m[1], -1), b = parseIntSafe(m[2], -1);
    if (b <= 0 || b > 6) return null;
    return [Math.min(a, b), b];
}

function shortText(s) {
    s = s == null ? "" : String(s);
    return s.length > 14 ? s.substring(0, 14) : s;
}

// 点顶部页签（普通/高级/稀有/英雄）；认不到就跳过整页，绝不赌坐标
function tapBookTab(name) {
    if (bookTabSpots == null) {
        bookTabSpots = {};
        var top = api.ocr(R_BK_TABS);
        for (var i = 0; i < top.length; i++) {
            var s = norm(top[i].text);
            for (var j = 0; j < BK_TABS.length; j++) {
                if (!bookTabSpots[BK_TABS[j]] && s.indexOf(BK_TABS[j]) >= 0) {
                    bookTabSpots[BK_TABS[j]] = { cx: top[i].cx, cy: top[i].cy };
                }
            }
        }
    }
    var hit = bookTabSpots[name];
    if (!hit) {
        api.log("顶部认不出页签「" + name + "」，跳过这一页");
        return false;
    }
    api.tap(hit.cx, hit.cy);
    api.sleep(1600);
    return true;
}

// 点一个套装图标 → 看详情底部「登记」→ 点 → 确认 → 判据（横幅/进度）
function collectBookSlot(x, y, rowIdx, before) {
    api.tap(x, y);
    api.sleep(1200);
    var btn = api.ocr(R_BK_REG);
    // 底部按钮条只有详情打开时才存在；必须至少认出「强化/替换/登记」之一，
    // 否则说明图标点空/界面没切，此时绝不能按返回（会把整个图鉴页关掉）。
    if (!findWord(btn, ["强化", "替换", "登记", "登录"])) {
        api.log("图标(" + x + "," + y + ")点开没反应（空格/界面没切）");
        return false;
    }
    var reg = findWord(btn, BK_REG_WORDS);
    if (!reg) {
        // 登记是灰的 = 缺件/强化等级不够：按需求 §8.4c 跳过，不硬点
        api.log("详情没有可点的「登记」（缺件或强化等级不够）→ 跳过（" + summaryOf(btn, 4) + "）");
        api.log("关详情 → 点详情 X @" + X_CLOSE + "," + Y_CLOSE + "（不按返回键）");
        api.tap(X_CLOSE, Y_CLOSE);
        api.sleep(800);
        return false;
    }
    api.log("详情「" + reg.text + "」可点 @" + reg.cx + "," + reg.cy + " → 点");
    api.tap(reg.cx, reg.cy);
    api.sleep(1400);
    if (!confirmOk("收藏登记")) {
        api.log("登记确认框没点掉 → 放弃这件");
        return false;
    }
    api.sleep(1500);
    if (api.find("完成道具收藏", R_BK_BANNER) || api.find("书签", R_BK_BANNER)) {
        api.log("收藏成功（认出「完成道具收藏书签」横幅）");
        return true;
    }
    var after = parseBookProgress(bookRowText(BK_ROW_Y0 + BK_ROW_PITCH * rowIdx));
    if (before != null && after != null && after[0] > before[0]) {
        api.log("收藏成功（行进度 " + before[0] + "/" + before[1]
            + " → " + after[0] + "/" + after[1] + "）");
        return true;
    }
    api.log("点了登记+确认，但进度没变、也没认出完成横幅 → 不算成功");
    return false;
}

// 4 页签 × 5 行逐行登记；返回成功件数
function collectBookPages() {
    var ok = 0, tried = 0;
    for (var p = 0; p < BK_TABS.length; p++) {
        if (!tapBookTab(BK_TABS[p])) continue;
        for (var r = 0; r < BK_ROWS; r++) {
            var y = BK_ROW_Y0 + BK_ROW_PITCH * r;
            var row = bookRowText(y);
            var prog = parseBookProgress(row);
            if (prog == null) {
                api.log("第 " + (r + 1) + " 行读不到进度（" + shortText(row) + "），跳过");
                continue;
            }
            if (prog[0] >= prog[1]) continue;      // 已收满
            var total = prog[1];
            if (total < 1 || total > 3) total = 3;
            api.log("第 " + (r + 1) + " 行「" + shortText(row) + "」进度 "
                + prog[0] + "/" + prog[1] + "，试 " + total + " 个图标");
            for (var s = 0; s < total; s++) {
                var x = BK_ICON_X_RIGHT - BK_ICON_PITCH * (total - 1 - s);
                tried++;
                setState("收藏 " + (p + 1) + "/4 页 第" + (r + 1) + "行");
                if (collectBookSlot(x, y, r, prog)) ok++;
            }
        }
    }
    api.log("图鉴扫描完成：试了 " + tried + " 个图标，成功登记 " + ok + " 件");
    return ok;
}

// 关图鉴页：右上返回箭头(1237,21)；关不掉再点一次，仍不行只记日志（不按返回键）
function closeBook() {
    api.tap(X_BK_CLOSE, Y_BK_CLOSE);
    api.sleep(1000);
    if (bookPageOpened()) {
        api.log("图鉴还开着 → 再点一次右上返回箭头 @" + X_BK_CLOSE + "," + Y_BK_CLOSE + "（不按返回键）");
        api.tap(X_BK_CLOSE, Y_BK_CLOSE);
        api.sleep(800);
    }
}

// 主流程入口（脚本线程，阻塞安全）：归位主界面 → 菜单→收藏 → 图鉴逐页登记 → 关页归位。
// 入参 reason 只用于日志/事件文案。无返回值（状态写进 stateText / api.event）。
// 成功判据只认「完成道具收藏书签」横幅或该行进度 x 变大（用户 11-02 确认）。
function doRun(reason) {
    api.log("开始自动收藏（" + reason + "）");
    api.event("开始自动收藏（" + reason + "）");

    if (!backToGame()) {
        api.log("回不到游戏主界面，放弃这次收藏");
        setState("失败：不在主界面");
        return;
    }

    // 2026-11-07：改走需求文档 §8 的「图鉴登记」路线。旧「详情→收藏」在不可直接收的件上
    // 会把画面切到道具收藏页却不登记（现场 02261），已由 collectBookSlot 取代。
    if (!openBook()) {
        api.log("图鉴打不开，放弃这次收藏");
        api.event("中止：图鉴打不开");
        setState("失败：图鉴打不开");
        backToGame();
        lastRunOk = true;
        return;
    }
    var ok = collectBookPages();
    lastRunOk = ok > 0;
    api.log("本轮收藏结束：登记成功 " + ok + " 件");
    api.event("收藏本轮结果：" + ok + " 件");
    setState(ok > 0 ? "已登记 " + ok + " 件" : "这轮没收到（10 分钟内不再重试）");
    closeBook();
    backToGame();
    setState("收藏结束");
    return;
}

/* ============================ MOD 导出 ============================ */

// 热更验证标记：这行在脚本每次（重）加载时打一条，改这里推包即可验证免安装热更
api.log("collect.js 已加载 —— 脚本热更验证标记 SCRV3");

// onTick 自动触发节流：每 10 分钟最多请求一次 runOnce（onTick 跑在 UI 线程，必须轻）
var lastAutoAt = 0;
// 2026-11-03：10 分钟太久了 —— 负重超阈值是「会死人」的事（>50% 不回血不回蓝），
// 用户明确要求「超 50% 就收藏」。改成 60 秒；真正跑不跑由 runOnce 里的负重判定决定，
// 负重 ≤50% 时只多一次 OCR（几百毫秒），代价可以接受。
var AUTO_GAP_MS = 60 * 1000;
// 394（用户 2026-11-10 硬规则）：失败不再退避 —— 上一轮一件都没登记成功也按正常节奏重试，
// 只把失败原因记进日志（原来的 FAIL_BACKOFF_MS = 10 分钟已删除）。
var lastRunOk = true;

// MOD 导出：ScriptHost.build 依它判定脚本可用；ScriptModule 从这里取
// id/title/order/defaultEnabled/status/onTick/runOnce。
// onTick(nowMs) 跑在 UI 线程：只做节流（entryInProgress / AUTO_GAP_MS）并返回是否请求 runOnce，
// 禁止 sleep/OCR；入参 nowMs 为宿主时钟（0/缺省按 0 处理）。lastAutoAt 是模块级内存态。
// runOnce(reason) 跑在脚本线程：自动触发（reason 含 "onTick"）先读负重，<50% 直接跳过，
// 读不到则 return false；手动/远程一律 doRun 照跑。
var MOD = {
    id: "collect",
    title: "自动收藏",
    order: 31,
    desc: "图鉴驱动：安全上限内强化并收藏（武器≤+6 防具≤+4），超限的分解",
    // TODO(待确认): 本文件 defaultEnabled=true，而 Java CollectionModule.defaultEnabled()=false
    //   （会动装备，Java 侧刻意默认关）。JS 兜底生效时默认勾选状态会改变，需确认哪边为准。
    defaultEnabled: true,
    // status：无入参，返回 stateText（UI 线程调用，只读内存，不触发任何点屏/OCR）。
    status: function () { return stateText; },
    // 触发规则（用户 2026-11-02 确认）：识别到负重超过 50% 就执行收藏功能。
    // onTick 只做节流判断（禁止 OCR/sleep —— UI 线程），负重检查放到 runOnce 的脚本线程里做。
    // onTick 入参 nowMs=宿主毫秒时钟；返回 true 表示请求宿主起 js 线程跑 runOnce。
    // 只读 api.entryInProgress() 与内存 lastAutoAt，不 OCR/不 sleep；不足 AUTO_GAP_MS 返回 false。
    onTick: function (nowMs) {
        if (api.entryInProgress()) return false;
        var now = nowMs || 0;
        var gap = AUTO_GAP_MS;
        if (now - lastAutoAt < gap) return false;
        lastAutoAt = now;
        return true;
    },
    // runOnce 入参 reason=触发文案（null 按"手动"）；返回 boolean。
    // 自动触发（含 "onTick"）先读负重：<50% 返回 true 不跑、读不到返回 false；其余直接 doRun。
    // 副作用：同步跑完整个收藏流程（点屏/长按/OCR/睡眠），由 ScriptModule 的 js 线程承载。
    runOnce: function (reason) {
        var why = reason == null ? "手动" : String(reason);
        // 自动触发（onTick）：负重 ≤50% 就不用收藏（手动/远程触发一律照跑）
        if (why.indexOf("onTick") >= 0) {
            // 先直接读右上角负重 —— 主界面判定经常误判（顶栏 OCR 认不出字）。
            // v416：读不到就直接跳过本轮，不再"归位重试"，更不按系统返回键。
            var pct = weightPct();
            if (pct >= 0 && pct < 50) {
                api.log("负重 " + pct + "% 未超 50%，不用收藏（自动触发跳过）");
                stateText = "负重 " + pct + "%，不用收藏";
                lastRunOk = true;
                return true;
            }
            if (pct < 0) {
                api.log("读不到负重（画面被挡/不在主界面），这轮自动收藏跳过");
                stateText = "读不到负重，跳过";
                lastRunOk = true;
                return false;
            }
            api.event("负重 " + pct + "% 超 50% → 开始自动收藏");
        }
        doRun(why);
        return true;
    }
};

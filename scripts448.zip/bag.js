// =====================================================================
// 背包清理模块（bag.js）—— v2.0.0 由原生 BagModule 迁入脚本层
// =====================================================================
// 为什么必须做（2026-10-31 用户实测确认）：负重超过 50% 以后角色**不回血不回蓝**
//（屏幕出红字「负重超过50%，不会恢复生命、魔力」）。奶妈没蓝 → 加不上血 → 在营地被打死。
// 所以负重是生死线，不只是背包空间问题。
//
// 界面路径（真机标定，1280x720）：
//   主界面右上角「43%」就是负重（(1028,60) 点它开背包）
//   → 背包物品格 4 列 × 5 行 → 点格子选中 → 底部「详情」看属性
//   → 详情面板底部第二排「分解」→ 确认框「确定」
//
// 清法顺序（用户定的）：
//   1) 先去村庄仓库点「自动保管」（游戏里已配好存放规则）——不毁装备、不花钱；
//   2) 存完还超阈值，才回来先试「安全收藏」（收藏按钮不灰才点，弹窗当唯一判据），
//      收藏不了的再分解。紫装/红装、身上穿的一律不动。
//
// 实测踩到的坑（迁 JS 原样保留）：
//   · OK_WORDS 绝不放「收藏」：弹窗正文写着「收藏后该道具将消失」，contains 会命中
//     正文 → 点正文还报成功（2026-11-02 03:00「假成功 20 件」的根因）。
//   · 详情面板底部的「分解」常态是灰的，灰字 OCR 认不出，但坐标不变 —— 点灰按钮
//     游戏没反应，正好当「不可分解」的判据。
// =====================================================================

// —— 模块注册 / 加载 / 兜底（核心层 ScriptHost，只读说明）——
// · ModuleManager 调用 ScriptHost.build("bag.js", BagModule 实例)：ScriptEngine 已就绪且本文件
//   存在 MOD 对象 → 返回 ScriptModule 包住本文件；面板显示的 id/title/order/defaultEnabled
//   全部取自文件末尾的 MOD（id="bag" / order=30 / defaultEnabled=true），不是 Java 的 BagModule。
// · MOD.id 必须与 Java BagModule.id() 一致（"bag"）：核心层 BagGuard 按 id 取模块，
//   holdScreen("bag") 的占屏凭据也用这个 id，改 id 会让负重守护找不到模块。
// · 文件缺失 / Rhino 编译求值抛错 / MOD 不是 Scriptable → ScriptHost.build 落警告并返回
//   Java BagModule 实例（JS 优先、Java 兜底），本文件逻辑随即完全不执行。
// · 热更：ScriptUpdateManager 解包后调 ScriptHost.reloadScriptModules() 原地重估本文件；
//   ScriptModule.isRunning() 为真时本轮跳过、下轮再刷。
// · 回调约定：宿主只调 MOD.status() / MOD.runOnce(reason)，onTick 由 ScriptModule 在 UI 线程调用。

/* ============================ 常量区（全部集中在这，热改只动这里） ============================ */

// 坐标（1280x720 真机标定）
// 2026-11-03 04:02 实拍改正：右上角那一组是「图标在上、百分比文字在下」，
// 真正能点开背包的是**上面那个图标**（y≈32），点文字「63%」那一行毫无反应 ——
// 之前一直点 y=60，所以每次都是「点了 3 次都没出现背包面板」。
// 实测：点 (1030,32) 背包立刻弹出（标题「背包」、页签 全部 88/124）。
// 2026-11-03 实拍：能点开背包的是百分比文字**正上方**那个图标，实测 (1031,32) 一点就开。
var X_BAG_ICON = 1031, Y_BAG_ICON = 32;
var X_BREAK = 1103, Y_BREAK = 594;        // 详情面板底部第二排「分解」（灰字认不出，坐标固定）
var X_STORE_AUTO = 1010, Y_STORE_AUTO = 654;   // 仓库「自动保管」
var X_STORE_ALL = 1171, Y_STORE_ALL = 654;     // 仓库「全部保管」（兜底）
// A5：删除原 COLLECT_CAND 盲点候选 —— 4 个没实测过的坐标 + confirmOk 自动确认，
// 若压到「删除」键会真删装备。铁律：坐标没实测一律 OCR 定位，认不出「收藏」就记日志跳过。

// 详情面板底部那一排按钮
var R_DETAIL_BTN = [56, 74, 100, 96];
// 背包物品格中心（4 列 × 5 行，实测像素剖面量出来的）
var GX = [990, 1063, 1136, 1209];
var GY = [178, 250, 322, 394, 466];
// 背包底栏「详情」
var X_INFO = 1061, Y_INFO = 576;
// 详情面板右上角的 X（关掉详情回背包）
var X_CLOSE = 1223, Y_CLOSE = 95;
// v416：副页右上「→]」返回箭头（btnlib: ui.back_arrow，1280x720 实拍 rect 1204,10-1252,62）
// 铁律：任何"返回"都只点这个图标或页面自己的 X，绝不注入系统返回键。
var UI_BACK = [1228, 36];

// 扫描区域（百分比）
// 2026-11-03 05:20 实拍重标：右上角这一排是「活动 商店 [背包56%] 技能 任务 菜单」，
// 百分比文字中心实测在 x≈855,y≈57（占屏 66.8%,7.9%），图标在它正上方 14px。
// 原来写的 [77,4,87,12] 框到「技能/任务」那边去了 —— 所以负重一直读不到、读错。
// 2026-11-03 实拍（HUD OCR 实测）：右上角一排是 活动(904) 商店(965) [56%](1031) 技能(1091) 任务(1155) 菜单(1216)，
// 百分比文字 bbox 1014~1047 / 51~69 → 79.2%~81.8% × 7.1%~9.6%。
// ★ 上一版误改成 63~71%（806~909，那是「活动」左边的空白），反而读不到，这里改回并收紧。
var R_WEIGHT = [78, 6, 83, 11];        // 主界面右上角负重百分比
var R_WEIGHT_WIDE = [74, 2, 100, 13];  // 兜底：整条 HUD 右段（增益图标增减会让百分比左右移）
var R_DETAIL = [56, 6, 100, 96];       // 右侧详情面板
var R_NAME = [56, 18, 100, 26];        // 详情面板顶部装备名（判品级只看这条）
var R_DIALOG = [25, 25, 75, 80];       // 屏幕正中那类「是否……」确认框
var R_BAG_OPEN = [68, 12, 99, 30];     // 背包面板打开后会出现的字
var R_NPC = [2, 6, 24, 58];            // 村庄左侧 NPC 交互列表（「仓库管理员」在这里）
var R_WH = [4, 8, 34, 24];             // 仓库面板左上角「保管目录」
var R_BAGCOUNT = [80, 10, 96, 17];     // 仓库界面右上「背包 96/124」计数

// 小字放大 OCR 宽度
var OCR_BIG_W = 1280;

// 词表（铁律：无泛词。★绝不能放「收藏」——弹窗正文写着「收藏后该道具将消失」；
// ★A11 也不放「分解/领取」——正文里「分解后…」「领取后…」同样会被 contains 命中）
var BAG_OPEN_WORDS = ["背包", "全部", "装备", "材料", "整理", "批量"];
var OK_WORDS = ["确定", "确认"];

// 正则
var P_PCT = /(\d{1,3})\s*%/;
var P_DIGITS = /^(\d{1,4})\D?$/;       // 「45%」实测会被 OCR 认成「459」，兜底读数
var P_COUNT = /(\d{1,3})\s*\/\s*(\d{1,3})/;

/* ============================ 运行态 ============================ */

var stateText = "待命";
// dismissDialog 里认出「确定要结束游戏吗」时置位：那就是主界面
var hudConfirmed = false;

/* ============================ 工具 ============================ */

// 文本归一：null 变空串、去半角空格/全角空格、再 trim。所有 contains 比较前都必须过它，
// 否则 OCR 结果里的空格会让「确定」这类短词匹配不上。入参任意，返回 String（不改入参）。
function norm(s) { return (s == null ? "" : String(s)).replace(/ /g, "").replace(/\u3000/g, "").trim(); }

// 安全十进制解析：解析失败/NaN 返回调用方给的 def（本项目统一用 -1 当「读不到」）。
// 不做范围校验，范围由调用点自己判（例如负重必须 0~100）。
function parseIntSafe(s, def) {
    var v = parseInt(String(s).trim(), 10);
    return isNaN(v) ? def : v;
}

// 只改内存里的状态文本；MOD.status() 每次被宿主查询时读它（无副作用、不点屏、不写盘）。
function setState(s) { stateText = s; }

// 在 OCR 块列表里找第一个 text 包含 key 的块（contains 匹配，不是精确匹配）。
// 返回该块（含 text/cx/cy/t/b）；没有返回 null。副作用无（只读）。
function findIn(items, key) {
    for (var i = 0; i < items.length; i++) {
        if (norm(items[i].text).indexOf(key) >= 0) return items[i];
    }
    return null;
}

// A8 裁决：findBottom 两边（bag.js / BagModule）都是死代码，删掉

/* ============================ 负重 ============================ */

// 主界面右上角读负重百分比，读不到返回 -1（% 被认成数字时走 P_DIGITS 兜底）
function weightPct() {
    var items = api.ocrBig(R_WEIGHT, OCR_BIG_W);
    for (var i = 0; i < items.length; i++) {
        if (items[i].text == null) continue;
        var t = norm(items[i].text);
        var m = P_PCT.exec(t);
        if (m) {
            var v = parseIntSafe(m[1], -1);
            if (v >= 0 && v <= 100) return v;
        }
        // 兜底：% 被认成数字/字母时（「45%」→「459」「45g」），3~4 位取前两位
        var d = P_DIGITS.exec(t);
        if (d && d[1].length >= 3 && d[1] !== "100") d[1] = d[1].substring(0, 2);
        if (d) {
            var v2 = parseIntSafe(d[1], -1);
            if (v2 >= 0 && v2 <= 100) return v2;
        }
    }
    api.log("右上角没认出百分比：" + (items.length ? items[0].text : "（OCR 空）"));
    return -1;
}

// 背包开着的时候，先点背包自己的 X 收起再读（绝不按系统返回键）
function readWeightNow() {
    var pct = weightPct();
    if (pct >= 0) return pct;
    if (bagOpened()) {
        api.log("负重读不到且背包开着 → 点背包 X @" + X_CLOSE + "," + Y_CLOSE + " 收起再读（不按返回键）");
        api.tap(X_CLOSE, Y_CLOSE);
        api.sleep(1000);
        return weightPct();
    }
    api.log("负重读不到，背包也没开 → 本轮跳过（不按返回键）");
    return -1;
}

/* ============================ 界面导航 ============================ */

// 画面校验：扫 R_BAG_OPEN（背包面板右上标题/分类行），任一 BAG_OPEN_WORDS 命中即算背包开着。
// 无入参；返回 boolean。副作用仅一次同步 OCR（毫秒级）。OCR 空/全不命中都返回 false
// （所以「背包其实开着但 OCR 没认出来」会被当成打不开，进而触发重试）。
function bagOpened() {
    var t = api.ocr(R_BAG_OPEN);
    if (t.length === 0) return false;
    for (var i = 0; i < t.length; i++) {
        var s = t[i].text == null ? "" : t[i].text;
        for (var w = 0; w < BAG_OPEN_WORDS.length; w++) {
            if (s.indexOf(BAG_OPEN_WORDS[w]) >= 0) return true;
        }
    }
    return false;
}

// 打开背包，并且验证真的打开了（点完必须扫到背包面板，重试 3 次）
// 找右上角带 % 的那块（先窄框，再整条 HUD 兜底）
// 在当前画面里找「带 % 的负重文字块」，供 openBag() 第 2/3 轮定位背包入口。
// 先扫窄框 R_WEIGHT、再扫整条 HUD R_WEIGHT_WIDE（ocrBig 放大到 1280 宽，小字才认得出）。
// 无入参；返回带 % 的块（用 .cx/.cy）；两框都没有返回 null。副作用：2 次 OCR。
function weightHit() {
    var regs = [R_WEIGHT, R_WEIGHT_WIDE];
    for (var r = 0; r < regs.length; r++) {
        var w = api.ocrBig(regs[r], OCR_BIG_W);
        for (var k = 0; k < w.length; k++) {
            if (w[k].text != null && w[k].text.indexOf("%") >= 0) return w[k];
        }
    }
    return null;
}

// 打开背包，并且验证真的打开了：每个候选位置点完都扫一次面板，没开就换下一个位置
function openBag() {
    for (var i = 0; i < 3; i++) {
        if (api.entryInProgress()) {
            api.log("进游戏进行中，清理推迟（背包不再重试）");
            return false;
        }
        // 第 1 轮：直接点标定坐标（1031,32 实测一点就开），不做 OCR。
        // 位置是死的就别每次重新算 —— 固定坐标 + 画面校验，校验不过再识别。
        if (i === 0) {
            api.log("点背包图标 @" + X_BAG_ICON + "," + Y_BAG_ICON + "（标定坐标，不识别）");
            api.tap(X_BAG_ICON, Y_BAG_ICON);
            api.sleep(1800);
            if (bagOpened()) {
                api.log("背包已打开");
                return true;
            }
            api.log("标定坐标没打开背包，改用识别方式重试");
            continue;
        }
        var hit = weightHit();
        var tries = [];
        if (hit) {
            // 图标本体在百分比文字正上方（实测 57-14=43）
            tries.push([hit.cx, hit.cy - 14]);
            tries.push([hit.cx, hit.cy]);
        }
        tries.push([X_BAG_ICON, Y_BAG_ICON]);
        for (var t = 0; t < tries.length; t++) {
            api.log("点 " + tries[t][0] + "," + tries[t][1] + " 开背包（第 " + (i + 1) + " 轮第 " + (t + 1) + " 个位置）");
            api.tap(tries[t][0], tries[t][1]);
            api.sleep(2200);
            if (bagOpened()) {
                api.log("背包已打开");
                return true;
            }
        }
        api.log("第 " + (i + 1) + " 轮三个位置都没打开背包");
        api.sleep(500);
    }
    return false;
}

// 关右侧详情面板：点详情右上角 X(1223,95)，再等 700ms 让面板收起。
// 无入参、无返回值；点空/点偏不报错（调用方不会校验是否真的关了）。副作用：1 次点击 + 睡眠。
function closeDetail() {
    api.tap(X_CLOSE, Y_CLOSE);
    api.sleep(700);
}

// 中间弹了个「取消/确认」的框就点取消，清掉它
function dismissDialog() {
    var dlg = api.ocr(R_DIALOG);
    if (dlg.length === 0) return false;
    var cancel = findIn(dlg, "取消");
    if (!cancel) return false;
    var quit = findIn(dlg, "结束游戏") != null || findIn(dlg, "结束遊戏") != null;
    api.log("弹窗盖着屏幕（" + summary(dlg, 4) + "），点「取消」清掉");
    api.tap(cancel.cx, cancel.cy);
    api.sleep(800);
    // 「确定要结束游戏吗」只会从主界面按返回弹出来 —— 见到它就等于「本来就在主界面」
    if (quit) hudConfirmed = true;
    return true;
}

// 日志摘要：把前 max 个 OCR 块拼成「文本(cx,cy) | 文本(cx,cy)」。
// 入参 items=OCR 块数组、max=最多取几块；返回 String。仅用于日志，无副作用。
function summary(items, max) {
    var sb = [];
    for (var i = 0; i < items.length && i < max; i++) {
        sb.push(items[i].text + "(" + items[i].cx + "," + items[i].cy + ")");
    }
    return sb.join(" | ");
}

// v416：只点游戏内图标离开当前页，绝不注入系统返回键。
// 背包开着优先点背包 X；其余副页点右上「→]」返回箭头。
function tapPageBack(why) {
    if (bagOpened()) {
        api.log(why + "：背包开着 → 点背包 X @" + X_CLOSE + "," + Y_CLOSE + "（不按返回键）");
        api.tap(X_CLOSE, Y_CLOSE);
        return;
    }
    api.log(why + "：点副页右上返回箭头 @" + UI_BACK[0] + "," + UI_BACK[1] + "（不按返回键）");
    api.tap(UI_BACK[0], UI_BACK[1]);
}

// 归位到主界面：最多 2 轮「isOnMainHud 判 → 有弹窗先点取消 → 否则点页面自己的返回图标」，每轮 900ms。
// 无入参；返回 boolean（最终是否在主界面）。副作用：点击「取消」/页面 X/返回箭头、多次睡眠。
// 特例：dismissDialog 认出「结束要游戏」的框时会置 hudConfirmed，直接当已在主界面返回 true。
// v416：整条路径不再按系统返回键（旧版 4 轮 safeBack 已删除）。
function backToGame() {
    hudConfirmed = false;
    for (var i = 0; i < 2; i++) {
        if (api.isOnMainHud()) return true;
        if (dismissDialog()) {
            if (hudConfirmed) return true;   // 弹的是「结束游戏」，说明本来就在主界面
            api.sleep(900);
            continue;
        }
        tapPageBack("归位");
        api.sleep(900);
    }
    if (!api.isOnMainHud()) {
        api.log("归位：仍不在主界面，本轮停手等下一次心跳（不按返回键）");
    }
    return api.isOnMainHud();
}

/* ============================ 品级（靠文字颜色） ============================ */

// 读详情面板里装备名的颜色判断品级。紫装（英雄）= 不分解不收藏；红装（传说）同理
function gradeOf(region) {
    return api.gradeOf(region);
}

function isPrecious(grade) {
    // v2.1.0：api.gradeOf 返回可能是 Java String（NativeJavaObject），=== 永远 false
    // 会把紫/红装当普通装放过去 → 危险。先拼成 JS 字符串再比。
    var g = (grade == null ? "" : "" + grade);
    return g === "紫" || g === "红";
}

/* ============================ 确认框 ============================ */

// 弹确认框就点确定并验证弹窗真的没了；没有弹窗说明按钮是灰的
function confirmOk(what) {
    var dlg = api.ocr(R_DIALOG);
    if (dlg.length === 0) return false;

    // A11：先排除退出确认框 —— 弹的是「确定要结束游戏吗」时点「确定」就是退游戏，
    // 必须拦下来点「取消」（与原生 BagModule.confirmOk 同款）
    var quitDlg = false;
    for (var q = 0; q < dlg.length; q++) {
        var sq = norm(dlg[q].text);
        if (sq.indexOf("结束游戏") >= 0 || sq.indexOf("退出") >= 0 || sq.indexOf("离开") >= 0) quitDlg = true;
    }
    if (quitDlg) {
        var cancelBtn = findIn(dlg, "取消");
        api.log(what + "确认弹的是退出确认框（" + summary(dlg, 4) + "）→ 点取消，绝不点确定");
        if (cancelBtn) api.tap(cancelBtn.cx, cancelBtn.cy);
        api.sleep(800);
        return false;
    }

    var top = 999999, bot = 0;
    for (var i = 0; i < dlg.length; i++) {
        if (dlg[i].t < top) top = dlg[i].t;
        if (dlg[i].b > bot) bot = dlg[i].b;
    }
    var cut = top + (bot - top) * 55 / 100;

    var ok = null;
    for (var j = 0; j < dlg.length && !ok; j++) {
        if (dlg[j].cy < cut) continue;   // 正文区，跳过
        var s = norm(dlg[j].text);
        for (var w = 0; w < OK_WORDS.length; w++) {
            if (s.indexOf(OK_WORDS[w]) >= 0) { ok = dlg[j]; break; }
        }
    }
    if (!ok) {
        // 教训：认不出按钮就记日志放弃，绝不盲点角落
        api.log(what + "确认框没认出按钮（" + summary(dlg, 6) + "），不盲点，放弃这次");
        return false;
    }
    api.log(what + "确认框点「" + ok.text + "」@" + ok.cx + "," + ok.cy);
    api.tap(ok.cx, ok.cy);
    api.sleep(1500);

    // 验证：弹窗真的没了才算成功。以前不验证，点了正文也报成功
    var after = api.ocr(R_DIALOG);
    if (after.length > 0) {
        api.log(what + "点完弹窗还在（" + summary(after, 4) + "）→ 这次不算成功");
        var cancel2 = findIn(after, "取消");
        if (cancel2) {
            api.log(what + "→ 点「取消」收掉弹窗（不按返回键）");
            api.tap(cancel2.cx, cancel2.cy);
        } else {
            api.log(what + "→ 认不出「取消」，放弃这次（不按返回键）");
        }
        api.sleep(700);
        return false;
    }
    return true;
}

/* ============================ 安全收藏 / 单件分解 ============================ */

// 试一次「安全收藏」。成功（真的弹出确认框并点掉）返回 true
// A5：OCR 认不出「收藏」按钮就记日志跳过，绝不按未实测的候选坐标盲点
function doCollect() {
    var btn = api.ocr(R_DETAIL_BTN);
    for (var i = 0; i < btn.length; i++) {
        var s = String(btn[i].text == null ? "" : btn[i].text).replace(/ /g, "");
        if (s.indexOf("收藏") >= 0) {
            api.log("详情里认出「" + btn[i].text + "」按钮 (" + btn[i].cx + "," + btn[i].cy + ")");
            api.tap(btn[i].cx, btn[i].cy);
            api.sleep(1300);
            return confirmOk("收藏");
        }
    }
    api.log("详情底部认不出「收藏」（" + summary(btn, 5) + "），不盲点候选坐标，跳过收藏（A5）");
    return false;
}

// 详情面板开着：点「分解」（固定坐标）→ 等确认框 → 点确定
function doBreakFixed() {
    if (!api.tap(X_BREAK, Y_BREAK)) return false;
    api.sleep(1200);
    return confirmOk("分解");
}

/* ============================ 仓库自动存放 ============================ */

// 仓库界面右上「背包 X/Y」里的 X，读不到返回 -1
function bagCount() {
    var items = api.ocr(R_BAGCOUNT);
    for (var i = 0; i < items.length; i++) {
        var m = P_COUNT.exec(norm(items[i].text));
        if (m) {
            var v = parseIntSafe(m[1], -1);
            if (v >= 0 && v <= 300) return v;
        }
    }
    return -1;
}

// 去村庄仓库点「自动保管」，把能存的先存掉（仓库不毁装备、不花金币，优先做）
function autoStore() {
    // 点一次有时候只是「开始往那儿走」，走过去还得再点一次才开仓库；
    // 而且列表在走路时会被收起来。所以按「扫列表 → 点 → 等 → 复查」最多来 4 轮。
    var open = false;
    for (var attempt = 0; attempt < 4 && !open; attempt++) {
        var npc = api.ocr(R_NPC);
        var wh = null;
        for (var i = 0; i < npc.length; i++) {
            if (norm(npc[i].text).indexOf("仓库") >= 0) { wh = npc[i]; break; }
        }
        if (!wh) {
            if (attempt === 0) {
                api.log("左边没有「仓库管理员」（" + summary(npc, 6)
                    + "）→ 大概不在村庄，跳过仓库");
                return false;
            }
            break;
        }
        api.log("点「" + norm(wh.text) + "」@" + wh.cx + "," + wh.cy + "（第 " + (attempt + 1) + " 次）");
        if (!api.tap(wh.cx, wh.cy)) return false;

        // 给自动移动留时间：走到 NPC 旁边仓库才会弹开（真机约 10 秒）
        for (var w = 0; w < 8 && !open; w++) {
            api.sleep(1500);
            var wt = api.ocr(R_WH);
            for (var k = 0; k < wt.length; k++) {
                var s = norm(wt[k].text);
                if (s.indexOf("保管") >= 0 || s.indexOf("仓库") >= 0) { open = true; break; }
            }
        }
    }
    if (!open) {
        api.log("点了 4 次仓库都没开（距离太远 / 被战斗打断），这次跳过（不按返回键，下一轮再试）");
        return false;
    }

    // 自动保管规则没命中（比如全是身上穿的）时，补一刀「全部保管」。
    // 真机实测：「自动保管」点了常常一点反应都没有，「全部保管」是实的。
    var before = bagCount();
    api.tap(X_STORE_AUTO, Y_STORE_AUTO);
    api.sleep(3000);
    var after = bagCount();
    api.log("自动保管：背包 " + (before < 0 ? "?" : before) + " → " + (after < 0 ? "?" : after));
    api.event("仓库自动保管 1 次");

    var storeAll = api.loadConfigBool("store_all_fallback", true);
    if (storeAll && (before < 0 || after < 0 || after >= before)) {
        api.log("自动保管没动背包 → 补「全部保管」@" + X_STORE_ALL + "," + Y_STORE_ALL);
        api.tap(X_STORE_ALL, Y_STORE_ALL);
        api.sleep(3200);
        var after2 = bagCount();
        api.log("全部保管后背包 " + (after2 < 0 ? "?" : after2));
        api.event("仓库全部保管 1 次（自动保管没动静）");
    }

    // 关仓库：点右上「→]」返回箭头（绝不按系统返回键）；关不掉只记日志，下一轮再判
    api.log("仓库存完 → 点右上返回箭头 @" + UI_BACK[0] + "," + UI_BACK[1] + "（不按返回键）");
    api.tap(UI_BACK[0], UI_BACK[1]);
    api.sleep(1600);
    var whOpen = false;
    var chk = api.ocr(R_WH);
    for (var q = 0; q < chk.length; q++) {
        var sq = norm(chk[q].text);
        if (sq.indexOf("保管") >= 0 || sq.indexOf("仓库") >= 0) { whOpen = true; break; }
    }
    if (whOpen) api.log("仓库页还在（返回箭头没关掉）→ 本轮不重试，下一轮再判（不按返回键）");
    return true;
}

/* ============================ 主流程 ============================ */

function doClean(reason) {
    // 开跑前再查一次进游戏闸门（runOnce 包装里查完到真正开跑中间隔着 900ms）
    if (api.entryInProgress()) {
        api.log("进游戏进行中，清理推迟");
        setState("进游戏进行中，清理推迟");
        return;
    }
    var limit = api.loadConfigInt("limit_pct", 50);
    var target = api.loadConfigInt("target_pct", 40);
    var maxItems = api.loadConfigInt("max_items", 20);

    if (!backToGame()) {
        api.log("回不到游戏主界面，放弃这次清理");
        setState("失败：不在主界面");
        return;
    }

    var pct = weightPct();
    api.log("当前负重 " + (pct < 0 ? "读不到" : pct + "%") + "，阈值 " + limit + "%");
    // 自动触发（值守报上来的）才看阈值；手动点「立即清理」或远程指令一律照跑
    var auto = reason != null && String(reason).indexOf("自动") === 0;
    if (auto && pct >= 0 && pct < limit) {
        setState("负重 " + pct + "%，不用清");
        return;
    }

    setState("去仓库自动存放");
    if (autoStore()) {
        var p2 = weightPct();
        pct = p2;
        if (p2 >= 0) {
            api.log("仓库自动存放后负重 " + p2 + "%（阈值 " + limit + "%）");
            api.event("仓库自动存放 → 负重 " + p2 + "%");
            if (p2 < limit) {
                api.log("负重已经降下来了，不用分解");
                setState("仓库存完，负重 " + p2 + "%");
                return;
            }
        }
    }

    setState("打开背包");
    if (!openBag()) {
        setState("失败：背包打不开");
        api.log("背包打不开，这次清理没法继续（点了 3 次都没出现背包面板）");
        return;
    }

    var done = 0, handled = 0, collected = 0;

    for (var r = 0; r < GY.length; r++) {
        for (var c = 0; c < GX.length; c++) {
            if (handled >= maxItems) break;
            handled++;

            setState("第 " + (r + 1) + " 行第 " + (c + 1) + " 格");
            // 点格子选中 → 点底栏「详情」→ 右侧出装备详情
            api.tap(GX[c], GY[r]);
            api.sleep(700);
            api.tap(X_INFO, Y_INFO);
            api.sleep(1200);

            var nm = api.ocr(R_NAME);
            if (nm.length === 0) {
                closeDetail();   // 空格子 / 详情没打开
                continue;
            }
            var grade = gradeOf(R_NAME);
            if (isPrecious(grade)) {
                api.log("第 " + (r + 1) + " 行第 " + (c + 1) + " 格是" + grade + "装，跳过（不分解）");
                api.event("跳过" + grade + "装不分解");
                closeDetail();
                continue;
            }

            // 用户定的顺序：能安全收藏的先收藏（收藏掉的装备消失、负重降），
            // 收藏不了的（按钮是灰的）才分解
            setState("第 " + (r + 1) + " 行第 " + (c + 1) + " 格：先试安全收藏");
            if (doCollect()) {
                collected++;
                api.log("安全收藏成功 1 件（累计 " + collected + "）");
                api.event("安全收藏 1 件");
                closeDetail();
                continue;
            }

            var ok = doBreakFixed();
            closeDetail();
            if (ok) {
                done++;
                api.log("分解成功 1 件（累计 " + done + "）");
                api.event("分解 1 件" + (grade.length === 0 ? "" : "（" + grade + "）"));
            }

            if (done > 0 && done % 3 === 0) {
                var now = readWeightNow();
                if (now >= 0 && now <= target) {
                    api.log("负重已降到 " + now + "%，收工");
                    r = GY.length;
                    break;
                }
            }
        }
    }

    var after = readWeightNow();
    api.log("清理结束：安全收藏 " + collected + " 件、分解 " + done + " 件，负重 "
        + (after < 0 ? "?" : after + "%"));
    setState("收藏 " + collected + " / 分解 " + done + "，负重 " + (after < 0 ? "?" : after + "%"));
    api.event("负重清理：收藏 " + collected + " 件、分解 " + done + " 件 → "
        + (after < 0 ? "?" : after + "%"));

    // 背包开着会影响打怪，点背包 X 关掉（不按返回键）
    if (!bagOpened()) {
        api.log("清理结束后背包已关，不再点（不按返回键）");
        return;
    }
    api.log("清理结束 → 点背包 X @" + X_CLOSE + "," + Y_CLOSE + "（不按返回键）");
    api.tap(X_CLOSE, Y_CLOSE);
    api.sleep(800);
    if (bagOpened()) {
        api.log("背包还开着，再点一次 X（不按返回键）");
        api.tap(X_CLOSE, Y_CLOSE);
        api.sleep(600);
    }
}

/* ============================ MOD 导出 ============================ */

// MOD 导出：ScriptHost.build 靠它判断「脚本可用」，ScriptModule 从这里取 id/title/order/
// defaultEnabled/status/runOnce。
// runOnce(reason) 说明：入参 reason 是触发来源文案（"自动…" 才看阈值；"手动"/"远程…" 一律照跑），
// 为 null 时按"手动"处理；始终直接同步执行 doClean 再返回 true（真实成败看 status 文本与日志）。
// 注意本模块的 runOnce 不自己起线程：ScriptModule 已在独立 js 线程里调用它，阻塞是安全的。
var MOD = {
    id: "bag",
    title: "背包清理",
    order: 30,
    desc: "负重超阈值：先去村庄仓库自动保管，还超再分解多余装备（紫装不分解）",
    defaultEnabled: true,
    status: function () { return stateText; },
    runOnce: function (reason) {
        doClean(reason == null ? "手动" : reason);
        return true;
    }
};

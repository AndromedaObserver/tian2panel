// =====================================================================
// 每日领取模块（daily_claim.js）—— v2.0.0 由原生 DailyClaimModule 迁入脚本层
// =====================================================================
// 做什么（421 起只剩 1 项；「邮件」「成长支援」都已从每日领取摘除，游戏里成长支援入口已没了）：
//   1 每日奖励   —— JS 自己进面板点（菜单类只剩这一项）
//   4 每日分享邀请码（活动 → 英雄集结 页面里「去完成」→「去领取」）—— 未接入，不在本轮分母内
//   5 殷海萨的祝福（活动 → 殷海萨的祝福 →「祈福」→ 变「重新祈福」）—— 未接入，不在本轮分母内
//
// 规则（2026-10-30 改，原样保留）：
//   · 游戏每天 **05:00 刷新**，刷新后自动跑一次；之前跑的记录按游戏日算。
//   · **一天只领一次**：记录落盘（DailyPlan），重启/热更后也不会重领。
//   · 失败自动重试：394 起只记原因，不设次数上限、不做退避，下一轮心跳继续。
//   · 338 起不再有 00:00~04:59 静默区：凌晨也照常判定是否该跑；
//     真正防重复领取的是 dailySettled（今天已完成/已放弃），与 5 点刷新无关。
//
// v14（2026-11-09）改动：
//   · 任务条口径 3 → 5：脚本里不再放 `log 领取：` 标记（那会把总数锁成 3），
//     改由 JS 用 api.claimProgress(cur, 5) 显式推进，ActionFlow 因为标记数=0 不会覆盖。
//   · 第 4/5 项在同一个活动页里做完再返回（一次进页面，不来回进出）。
//   · 成败判据只看**按钮文案真的变了**：
//       第 4 项 去完成 →（点）→ 去领取 →（点）→ 去领取消失
//       第 5 项 祈福   →（点）→ 重新祈福
//     点了没变 = 失败，绝不因为「点过了」就记领到。
//   · 第 4 项没成功就不执行第 5 项；进度严格停在 4/5。
//   · 第 4/5 项失败不结束本轮，原地磨：图色（橙色/亮块）→ OCR 文字 → 回退重进页面，
//     每轮都落日志；单项超过 5 分钟上报一次（带页面/坐标/图色命中/OCR 文本/每轮轨迹）。
//
// v15（2026-11-09）改动：
//   · 第 4/5 项判据换成「自己 OCR 取文本块，比对点前/点后文案」，不再用 find 的 1 字容错
//     （345 实机把「可领取」当「去领取」命中，等于点了就算领到）。
//   · 第 5 项新增防花钻石：点祈福后若弹「消耗10钻石重新祈福」，说明今日免费已用 →
//     点「取消」，该项按「今日已祈福」计成功，绝不去点橙色「重新祈福」。
//   · 任务条不再每次调用都归零（同一轮 0/5 → 3/5 → 4/5 → 5/5 平滑推进）。
//
// v16（2026-11-09，用户口径）：红点彻底不参与判断。
//   · 删掉 R_DOT / ifdot / DOT_GATE / withoutDotGate / DEFAULT_STEPS 整条 ActionFlow 脚本；
//     红点只在日志里打一行参考值，代码里没有任何 if 读它。
//   · 前 3 项改成 JS 自己进页面：读按钮态（可领取 / 终态 / 灰或无）→ 可领取才点；
//     点完必须看到真实变化（OCR 文案变了或橙色占比明显下降）才记「本次领到」；
//     点了没变化 → 日志写「点了但没变化」/「按钮可能位置不对，本轮不做该项」，不记账、不假装成功。
//   · 已是终态（已领取/已完成/已领完）→ 这一项算完成，跳过不点；
//     灰按钮 / 没有这一项 → 跳过，且**不记账**（最终日志单列「跳过 N 项」）。
//
// v17（2026-11-09，两条实机问题）：
//   · 菜单关掉后打不开：根因是每日奖励面板没有「结束」按钮，旧 closePopup 点 (960,655) 关不掉，
//     面板一直盖着 → 下次点菜单就是点空。现在各面板点自己的关闭位（每日奖励右上收起 /
//     成长支援右下结束），点完轮询「真的关掉」；开菜单改成轮询看到「每日」出现，不补点、不加重试。
//   · 「领取奖励」点不中：坐标暂不改（等菜单弹窗实拍复核），点完没变化 → 打
//     「按钮可能位置不对，本轮不做该项」，不记账、不假装成功。
//   · 第 4/5 项（英雄集结 / 殷海萨的祝福）流程还在等用户确认 → **没有接进执行流程**，
//     只做前 3 项，日志与完成消息写「第4/5项未接入」，绝不按未复核坐标乱点。
// =====================================================================

// —— 模块注册 / 加载 / 兜底（核心层 ScriptHost，只读说明）——
// · ModuleManager 调 ScriptHost.build("daily_claim.js", DailyClaimModule 实例)：ScriptEngine 就绪
//   且本文件存在 MOD 对象 → 返回 ScriptModule（JS 驱动）；面板上的 id/title/defaultEnabled
//   取自文件末尾的 MOD（id="daily_claim" / defaultEnabled=false），order 取原生实现。
// · MOD.id 必须与 Java DailyClaimModule.id() 一致（"daily_claim"）：DailyPlan 记账、
//   AutoDailyModule 队列、面板开关 key 都按这个 id 关联。
// · 文件缺失 / Rhino 编译求值抛错 / MOD 不是对象 → ScriptHost.build 落警告并回退 Java
//   DailyClaimModule（JS 优先、Java 兜底），本文件不再执行。
// · 热更：ScriptUpdateManager 解包后 ScriptHost.reloadScriptModules() 原地重估；isRunning() 时推迟。
// · 宿主调用面：MOD.status() / MOD.onTick(nowMs) 在 UI 线程（必须轻），MOD.runOnce(reason)
//   在脚本线程（startStepsSync 阻塞安全）。

/* ============================ 常量区（全部集中在这，热改只动这里） ============================ */

// 05:00 换日（api.minutesSinceReset() 归零）后条件满足就直接跑，不做任何人为推迟。
// 344 之前这里有一套「05:00 后随机等 1~18 分钟起跑」的自保设定，用户从没要求过，已整段删除；
// 本文件与 Java 侧都不再读写任何起跑延迟相关的配置键。
// 刚重启那 20 秒截屏面还没建好，别急着跑
var BOOT_GRACE_MS = 20000;
// 394（用户 2026-11-10 硬规则）：onTick 不再做任何重试间隔 —— 失败只记原因，下一轮立刻再试。
// 唯一保留的是下面的 1 秒 lastCheck（同一帧内重复进 onTick 的物理去抖，不是冷却）。
// 红点只做日志参考，不参与任何判断（用户口径）。
// 区域：菜单按钮右上角（百分比）。只读像素，不产生分支。
var DOT_RECT = [91, 2, 100, 14];

// 334：只有「长任务条上没有长任务」或「正在跑的就是挂机」才允许开始。
// 状态码由宿主 TaskHud.longTaskState() 给（与任务条文案同源）：
//   idle=待命 / hang=正在挂机（值守这类短任务）/ daily=每日自己在跑
//   / dungeon=副本 / oracle=神谕 / revive=复活 / entry=进游戏中 / paused=人工暂停
// 副本、神域这类长任务在跑时不插队，等它跑完下一轮心跳自然会捡起来（不记失败、不烧重试次数）。
// 338：拦截时必须留痕（之前裸 return false，日志里查不到任何"为什么没跑"）。
// 394：改成「状态变化时记一条」（按 st 变化，不做时间门/限频）。
var lastBlockState = "";
// 341：被 dailySettled（今日已完成）拦下时的观测日志 —— 394 改为只在「刚进入已完成」时记一条。
// 用户要的是「能看见到底跑没跑」，不能只留一个裸 return 让人猜。
var settledLogged = false;

// —— 本轮总项数：只剩「每日奖励」这一步，分母就是 1（421：邮件、成长支援先后摘除，不许分母大于实际步骤）——
// 第 4/5 项（英雄集结 / 殷海萨的祝福）代码还在、但**没有接进执行流程**，所以不计入分母。
var TOTAL_ITEMS = 1;

function longTaskAllows() {
    var st = "idle";
    try { st = String(api.longTaskState()); } catch (e) { st = "idle"; }
    if (st === "idle" || st === "hang") { lastBlockState = ""; return true; }
    if (st !== lastBlockState) {
        lastBlockState = st;
        api.log("让路：长任务条状态=" + st + "（不是 idle/hang），本轮不插队");
    }
    return false;
}

// 菜单 / 弹窗几何（沿用实机标定值，1280×720）
var MENU = {
    // 2026-11-09 实拍校准（素灵 1280×720）：三条横线图标中心 (1220,30)，红点角标在 (1240,19)。
    // 旧值 97.5%,5.6%=(1248,40) 已经贴到图标右边缘，点空过 → 修成图标中心。
    btn: [95.3, 4.2],             // 右上菜单按钮（三条横线）
    daily: [75.4, 45.4],          // 菜单项「每日」
    popupBtn: [75.7, 43.9],       // 弹窗橙色「领取奖励」中心
    popupRect: [67, 41, 84, 47],  // 弹窗按钮 OCR 区（点前/点后比对）
    popupOrangeRect: [72.5, 42.5, 78.9, 46.8],  // 按钮本体（实拍 928,306~1010,337）
    closeX: [96.9, 5.3],          // 每日奖励页右上「→]」收起（实拍 1240,38）
    panelTitle: [70, 2, 99, 10]   // 面板顶部标题「每日奖励 →]」（实拍）用来确认面板真的开了
};

// 终态文案：看到这些 = 这一项此前已领完（OCR 常见近形字一并收进来）
var TERMINAL_WORDS = ["已领取", "已完成", "已领完", "已领", "今日已领", "明日再来", "己领取", "已領取"];

/* ==================== 活动页第 4/5 项：实机标定坐标（1280×720）====================
 * 2026-11-09 用 226172261（#18 嘉宾4，1280×720 横屏）实机截图 + 设备端 OCR 地图标定：
 *   主城顶栏「活动」图标     OCR 读作「47872活动(867,57)」把数字和文字并成一块，中心偏左点不到，
 *                            所以这里用截图量的图标中心 (900,29) → 70.3%,4.0%。
 *   活动页左侧「英雄集结」   OCR (208,195) → 16.3%,27.1%（页面打开就可见，不需要滚动）
 *   活动页左侧「殷海萨的祝福」OCR 读作「股海萨的祝福(226,256)」→ 17.7%,35.7%
 *   英雄集结页「每日分享邀请码」右侧按钮 (1110,334) → 86.7%,46.4%
 *   祝福面板「祈福」按钮     OCR 读作「新福(770,532)」→ 60.2%,73.9%
 *   面板右上关闭 X           (1230,38) → 96.1%,5.3%
 * 竖向排布（参考）：活动页左侧导航依次是 福利/特惠/推荐/英雄集结/殷海萨的祝福/战盟红包/我要变强/征战贝欧娜/殷海萨的试炼。
 */
var ACT = {
    entry: [70.3, 4.0],
    navHero: [16.3, 27.1],
    navBless: [17.7, 35.7],
    shareBtn: [86.7, 46.4],
    shareRect: [83.5, 42.5, 90.0, 50.5],
    blessBtn: [60.2, 73.9],
    blessRect: [55.0, 68.0, 66.5, 80.5],
    closeX: [96.1, 5.3]
};
// 第 4/5 项单项最多磨多少轮（每轮 6~12 秒）；到顶才收手记失败
var ITEM_MAX_ROUNDS = 60;
// 单项超过这个时长（毫秒）就上报一次「卡住」，但继续磨
var STUCK_REPORT_MS = 300000;
// 回退重进页面的间隔轮数（图色+OCR 都点不动时）
var ROUNDS_BEFORE_REENTER = 3;

/* ============================ 运行态 ============================ */

var stateText = "待命";
var lastCheck = 0;
// 进程/脚本加载时间（BOOT_GRACE 防重启秒跑）
var bootAt = Date.now();
// 截屏尺寸缓存（tap 用真实像素，OCR 用百分比）
var _wh = null;

// 只改内存状态文本（MOD.status 读它）；无点屏/写盘副作用。
function setState(s) { stateText = s; }

/* ============================ 调度细节 ============================ */

// 红点只打日志：读一次像素，打印在日志里供核对，**不影响任何分支**。
// 脚本层没有「纯红像素」桥，这里打两个现有探针（橙色占比 + 亮块占比）作为参考值。
function logRedDot() {
    var orange = 0, bright = 0;
    try { orange = api.orangeRatio(DOT_RECT); } catch (e) { orange = 0; }
    try { bright = api.brightRatio(DOT_RECT, 60); } catch (e2) { bright = 0; }
    api.log("[红点] 菜单按钮右上角：橙色 " + orange + "%｜亮块 " + bright
            + "%（仅日志参考，不参与判断）");
}

/* ============================ 活动页小工具 ============================ */

function screenWh() {
    if (_wh != null) return _wh;
    var s = null;
    try { s = api.screenshot(); } catch (e) { s = null; }
    if (s != null && s.w > 0 && s.h > 0) _wh = [s.w, s.h];
    else _wh = [1280, 720];
    return _wh;
}

// 百分比 → 真实像素
function toPx(p) {
    var wh = screenWh();
    return [Math.round(wh[0] * p[0] / 100), Math.round(wh[1] * p[1] / 100)];
}

// 点一个百分比坐标，返回是否派发成功；日志带用途
function tapPct(p, why) {
    var xy = toPx(p);
    var ok = false;
    try { ok = api.tap(xy[0], xy[1]); } catch (e) { ok = false; }
    api.log("点击 " + why + " @(" + xy[0] + "," + xy[1] + ") → " + (ok ? "已派发" : "被拒"));
    return ok;
}

// 在区域里找词（api.find 自带 精确→包含→1 字容错）；找不到返回 null
function findIn(word, region) {
    try { return api.find(word, region); } catch (e) { return null; }
}

// 依次试多个候选词，命中第一个就返回 {hit, word}
function findAny(words, region) {
    for (var i = 0; i < words.length; i++) {
        var h = findIn(words[i], region);
        if (h != null) return { hit: h, word: words[i] };
    }
    return null;
}

// 区域 OCR 文本列表（上报用）
function ocrTexts(region) {
    var out = [];
    try {
        var arr = api.ocr(region);
        for (var i = 0; i < arr.length; i++) out.push(String(arr[i].text));
    } catch (e) { }
    return out;
}

function orangeAt(rect) {
    try { return api.orangeRatio(rect); } catch (e) { return 0; }
}

// 当前在哪个页面（上报用，按页面特征字判断）
function pageName() {
    try { if (api.isOnMainHud()) return "主城"; } catch (e) { }
    if (findIn("每日分享邀请码", [30, 22, 100, 62]) != null) return "活动页·英雄集结";
    if (findIn("当前祝福积分", [0, 55, 55, 92]) != null) return "活动页·殷海萨的祝福";
    if (findIn("英雄集结", [0, 12, 34, 74]) != null) return "活动页（左侧导航）";
    return "未知页面";
}

// 5 分钟卡住上报：一项一次；继续磨不停
function reportStuck(itemName, rounds, region, trail) {
    var page = pageName();
    var orange = orangeAt(region);
    var texts = ocrTexts(region);
    api.log("========== 每日领取卡住上报（单项超 5 分钟，继续重试） ==========");
    api.log("未完成项：" + itemName + "｜已试 " + rounds + " 轮｜当前页面：" + page);
    api.log("卡住区域（百分比）：" + region.join(",") + "｜图色命中：橙色占比 " + orange + "%");
    api.log("该区域 OCR 识别到：" + (texts.length > 0 ? texts.join(" | ") : "（空，疑似页面没打开/黑屏）"));
    api.log("每轮轨迹（最近 8 轮）：" + trail.slice(-8).join(" ／ "));
    api.log("==============================================================");
    try {
        api.event("每日领取卡住（" + itemName + "，已 " + rounds + " 轮）：页面=" + page
                + "，区域=" + region.join(",") + "，橙色=" + orange + "%"
                + "，OCR=" + (texts.length > 0 ? texts.join("/") : "空"));
    } catch (e) { }
}

/* ============================ 活动页导航 ============================ */

// 归位前先处理返回键留下的「确定要结束游戏吗？」确认框：只点「取消」，不点确定、不按返回。
function dismissExitDialog() {
    var hint = null;
    try { hint = findAny(["确定要结束游戏吗", "结束游戏"], [0, 20, 100, 60]); } catch (e) { hint = null; }
    if (hint == null) return false;
    var cancel = null;
    try { cancel = findIn("取消", [0, 35, 100, 75]); } catch (e2) { cancel = null; }
    if (cancel == null) {
        api.log("归位前发现「结束游戏」确认框，但认不到「取消」→ 只报不点");
        return false;
    }
    api.log("归位前发现「结束游戏」确认框（旧版返回键的遗留）→ 点「取消」@("
            + cancel.cx + "," + cancel.cy + ")，不结束游戏");
    try { api.tap(cancel.cx, cancel.cy); } catch (e3) { }
    api.sleep(900);
    return true;
}

// 确保回到主城：先 UiMap 三要素判，不在就走选键表点固定坐标（api.ensureHome），
// **不按返回键、不设次数上限、不加等待/冷却**；本轮没回成只报原因，下一轮心跳再判。
function ensureMainHud() {
    dismissExitDialog();
    try { if (api.isOnMainHud()) return true; } catch (e) { }
    try { api.ensureHome("每日领取"); } catch (e2) { }
    var ok = false;
    try { ok = api.isOnMainHud(); } catch (e3) { ok = false; }
    if (!ok) api.log("归位：不在主城，已按选键表点固定坐标（不按返回键）；本轮不点菜单项，下一轮心跳重试");
    return ok;
}

// 主城 → 活动页：点顶栏「活动」图标，等左侧「英雄集结」出现（最多点 3 次）
function enterActivityPage() {
    for (var k = 0; k < 3; k++) {
        tapPct(ACT.entry, "主城顶栏「活动」入口");
        var t0 = Date.now();
        for (var i = 0; i < 5; i++) {
            api.sleep(2200);
            if (findIn("英雄集结", [0, 12, 34, 74]) != null) {
                api.log("活动页已打开（认出左侧「英雄集结」，用时 "
                        + Math.round((Date.now() - t0) / 1000) + "s）");
                return true;
            }
        }
        api.log("活动页没打开（第 " + (k + 1) + " 次点「活动」后 11s 内仍认不到「英雄集结」）");
    }
    return false;
}

// 活动页 → 英雄集结面板：点左侧导航，等「每日分享邀请码」出现
function enterHeroPage() {
    var nav = findIn("英雄集结", [0, 12, 34, 74]);
    if (nav == null) { api.log("活动页里认不到左侧「英雄集结」入口"); return false; }
    api.log("点左侧导航「英雄集结」@(" + nav.cx + "," + nav.cy + ")");
    try { api.tap(nav.cx, nav.cy); } catch (e) { }
    for (var i = 0; i < 5; i++) {
        api.sleep(2000);
        if (findIn("每日分享邀请码", [30, 22, 100, 62]) != null) {
            api.log("英雄集结面板已打开（认出「每日分享邀请码」）");
            return true;
        }
    }
    api.log("英雄集结面板没打开（点了「英雄集结」后认不到「每日分享邀请码」）");
    return false;
}

// 英雄集结面板 / 祝福面板 → 活动页 → 主城（不按返回键：只点面板 X + 选键表固定坐标）
function backToMain() {
    api.log("回主城第 1 步：点面板右上关闭 X");
    tapPct(ACT.closeX, "面板关闭 X");
    api.sleep(1500);
    var page = pageName();
    if (page === "主城") { api.log("回主城：已在主城（1 步）"); return true; }
    dismissExitDialog();
    try { api.ensureHome("每日领取-活动页返回"); } catch (e) { }
    var ok = false;
    try { ok = api.isOnMainHud(); } catch (e2) { ok = false; }
    api.log("回主城结果：" + (ok ? "已回主城（X + 选键表固定坐标）"
            : "仍未回主城（当前 " + pageName() + "），不按返回键，下一轮心跳重试"));
    return ok;
}

/* ==================== 第 4 / 5 项共用：判据 = 「按钮文案真的变了」 ====================
 * 教训（345 实机 05:22）：api.find 自带「1 字容错」，把「可领取」当成「去领取」命中，
 * 点完只验证「去领取」不见了 → 等于「点了就算领到」。
 * 这里改成自己 OCR 取文本块：记录点前文案 → 点 → 再取文案，必须肉眼可见地变化才算成功；
 * 文案没变一律记失败，并把「点前→点后」原文写进日志，方便核对卡在哪一步。
 */

// 区域 OCR：返回 [{t:去空白文本, cx, cy}]，不做任何模糊匹配
function regionItems(region) {
    var out = [];
    try {
        var arr = api.ocr(region);
        for (var i = 0; i < arr.length; i++) {
            var t = String(arr[i].text == null ? "" : arr[i].text).replace(/\s+/g, "");
            if (t.length > 0) out.push({ t: t, cx: arr[i].cx, cy: arr[i].cy });
        }
    } catch (e) { }
    return out;
}

// 文本块拼成一行（日志 / 变化比对用）
function itemsText(items) {
    if (items == null || items.length === 0) return "";
    var a = [];
    for (var i = 0; i < items.length; i++) a.push(items[i].t);
    return a.join("|");
}

// 取第一个包含任一关键字的文本块
function pickItem(items, keys) {
    for (var i = 0; i < items.length; i++) {
        for (var k = 0; k < keys.length; k++) {
            if (items[i].t.indexOf(keys[k]) >= 0) return items[i];
        }
    }
    return null;
}

// 点文本块中心，日志带用途
function tapItem(it, why) {
    var ok = false;
    try { ok = api.tap(it.cx, it.cy); } catch (e) { ok = false; }
    api.log("点击 " + why + "「" + it.t + "」@(" + it.cx + "," + it.cy + ") → " + (ok ? "已派发" : "被拒"));
    return ok;
}

/* ==================== 前 3 项：进页面看按钮态，真变化才记账 ====================
 * 用户口径（2026-11-09）：不按红点判断；进各自页面看按钮本身：
 *   可领取 → 点；已是终态（已领取/已完成/已领完）→ 本项算完成、跳过；
 *   灰按钮 / 没有这一项 → 跳过，且不记账。
 * 点了但画面没变化 → 不记账，日志写「按钮可能位置不对，本轮不做该项」，本项跳过。
 */

// 菜单项「每日」文字所在小块（小区域 OCR，比扫整块菜单面板快很多）
var MENU_PROBE = [72, 41, 83, 50];

// 只看「每日」这一小块：true=菜单确实打开了
function menuVisible() {
    return findAny(["每日", "每白", "每曰"], MENU_PROBE) != null;
}

// 是否在主城（api.isOnMainHud 的异常兜底）
function isMainHud() {
    try { return api.isOnMainHud(); } catch (e) { return false; }
}

// 菜单是否已打开（认「每日」；OCR 常把「每日」认成「每白/每曰」）
// 2026-11-09：点完不再睡固定时长，改成轮询「看到菜单真的出来」；也不额外重试点击。
function openMenu() {
    if (menuVisible()) { api.log("菜单已打开（认出「每日」）"); return true; }
    if (!isMainHud()) {
        // 上一步弹窗/遮罩没退干净时，点菜单按钮是点空 → 如实说清楚，不在错页面上点
        api.log("点菜单前不认主城 HUD（当前 " + pageName() + "，疑似弹窗/遮罩残留）→ 本轮不做菜单项");
        return false;
    }
    tapPct(MENU.btn, "菜单按钮");
    var deadline = Date.now() + 8000;
    while (Date.now() < deadline) {
        if (menuVisible()) { api.log("菜单已打开（认出「每日」）"); return true; }
        api.sleep(600);
    }
    api.log("菜单没打开：点菜单按钮后 8 秒内 " + MENU_PROBE.join(",") + " 区域一直认不到「每日」");
    return false;
}

// 弹窗按钮态：claim=可领取 / already=终态 / none=灰按钮或没有这一项
function popupState() {
    var texts = regionItems(MENU.popupRect);
    var txt = itemsText(texts);
    var orange = orangeAt(MENU.popupOrangeRect);
    var lit = 0;
    try { lit = api.brightRatio(MENU.popupOrangeRect, 150); } catch (e) { lit = 0; }
    var term = pickItem(texts, TERMINAL_WORDS);
    if (term != null) return { kind: "already", orange: orange, lit: lit, text: txt, term: term.t };
    // 可领取 = 橙色实心按钮（实拍亮橙）；暗态按钮橙色 0%、亮块 0%，文字仍写「领取奖励」
    if (orange >= 25 || lit >= 25) return { kind: "claim", orange: orange, lit: lit, text: txt };
    if (pickItem(texts, ["领取", "领取奖励"]) != null) {
        return { kind: "dim", orange: orange, lit: lit, text: txt };
    }
    return { kind: "none", orange: orange, lit: lit, text: txt };
}

// 点前→点后是否算「真实变化」：转终态 / 文案变了 / 橙色占比明显下降
function popupChanged(before, after) {
    if (after.kind === "already") return true;
    if (after.text !== before.text) return true;
    if ((before.orange - after.orange) >= 8) return true;
    return (before.lit - after.lit) >= 12;
}

// 关面板：点这个面板自己的关闭位，然后轮询「真的关掉了」（回主城或菜单仍在），
// 不睡固定时长、不额外补点。返回是否确认关掉。
function closePanel(closeP, name) {
    tapPct(closeP, name + "·关闭");
    var deadline = Date.now() + 6000;
    while (Date.now() < deadline) {
        api.sleep(600);
        if (isMainHud()) { api.log("[" + name + "] 面板已关掉（回主城）"); return true; }
        if (menuVisible()) { api.log("[" + name + "] 面板已关掉（菜单仍在）"); return true; }
    }
    api.log("[" + name + "] 关闭后 6 秒内既没回主城也没认出菜单（当前 " + pageName() + "）");
    return false;
}

// 等面板真的出来：认面板顶部标题区；标题 OCR 常认不全（实机把「每日奖励」读成「母奖励一」），
// 所以 btnOk=true 的页面允许用「按钮区出现『领取』」兜底。成长支援页故意不给兜底：
// 页签没切过去时按钮区还是每日奖励的，兜底会把错页面当成了对页面。最多轮询 6 秒。
function waitPanel(name, keys, btnOk) {
    var deadline = Date.now() + 6000;
    var last = "";
    var btnTxt = "";
    while (Date.now() < deadline) {
        last = ocrTexts(MENU.panelTitle).join("|");
        for (var i = 0; i < keys.length; i++) {
            if (last.indexOf(keys[i]) >= 0) {
                api.log("[" + name + "] 面板已打开（标题认出「" + keys[i] + "」，OCR「" + last + "」）");
                return true;
            }
        }
        if (btnOk) {
            btnTxt = itemsText(regionItems(MENU.popupRect));
            if (btnTxt.indexOf("领取") >= 0) {
                api.log("[" + name + "] 面板已打开（标题 OCR「" + last + "」没认全，按钮区已出现「"
                        + btnTxt + "」）");
                return true;
            }
        }
        api.sleep(600);
    }
    api.log("[" + name + "] 面板没打开：6 秒内标题区 OCR「" + (last || "空") + "」不含 "
            + keys.join("/") + (btnOk ? "，按钮区「" + (btnTxt || "空") + "」也没有「领取」" : ""));
    return false;
}

// 菜单 →「每日」→ 每日奖励面板 → 判定/领取 → 右上收起
function claimDailyReward() {
    if (!openMenu()) return { kind: "fail", why: "菜单没打开（认不到「每日」）" };
    tapPct(MENU.daily, "菜单·每日");
    if (!waitPanel("每日奖励", ["奖励", "每日", "母奖"], true)) {
        closePanel(MENU.closeX, "每日奖励");
        return { kind: "fail", why: "每日奖励面板没打开" };
    }
    var r = claimCurrentPanel("每日奖励");
    closePanel(MENU.closeX, "每日奖励");
    return r;
}
// 当前面板（每日奖励）里的按钮态判定 + 点击 + 真实变化校验
function claimCurrentPanel(name) {
    var st = popupState();
    api.log("[" + name + "] 进页面：kind=" + st.kind + "｜橙色 " + st.orange + "%｜OCR「"
            + (st.text || "空") + "」");
    if (st.kind === "already") {
        api.log("[" + name + "] 已是终态「" + st.term + "」→ 本项此前已领，跳过不点（算完成）");
        return { kind: "already", why: st.term };
    }
    if (st.kind === "dim") {
        // 实拍（19:24 素灵）：今日已领时按钮是暗棕 avg≈(109,54,11)，文字仍是「领取奖励」，
        // 橙色 0%、亮块 0% → 不能当可领取，也不是「本次领到」；按钮态本身说明此前已领过。
        api.log("[" + name + "] 按钮是暗态（橙色 " + st.orange + "%、亮块 " + st.lit + "%，OCR「"
                + (st.text || "空") + "」）→ 视为此前已领，跳过不点（不算本次领到）");
        return { kind: "already", why: "暗态视为此前已领" };
    }
    if (st.kind === "none") {
        api.log("[" + name + "] 灰按钮/没有可领按钮（OCR「" + (st.text || "空") + "」，橙色 "
                + st.orange + "%）→ 跳过，不记账");
        return { kind: "skipped", why: "无可领按钮" };
    }
    tapPct(MENU.popupBtn, name + "·领取");
    api.sleep(2400);
    var st2 = popupState();
    api.log("[" + name + "] 点后：kind=" + st2.kind + "｜橙色 " + st2.orange + "%｜OCR「"
            + (st2.text || "空") + "」");
    if (popupChanged(st, st2)) {
        api.log("[" + name + "] 画面真实变化（「" + (st.text || "空") + "」→「" + (st2.text || "空")
                + "」，橙色 " + st.orange + "% → " + st2.orange + "%）→ 本次领到");
        return { kind: "claimed", why: "画面变化" };
    }
    api.log("[" + name + "] 点了但没变化（橙色 " + st.orange + "% → " + st2.orange + "%，OCR「"
            + (st.text || "空") + "」→「" + (st2.text || "空") + "」）→ 按钮可能位置不对，本轮不做该项，不记账");
    return { kind: "skipped", why: "按钮可能位置不对（点了没变化）" };
}

// 421 起只剩每日奖励一项；返回 {done,claimed,already,skipped,fail,items}
function runScriptItems() {
    var out = { done: 0, claimed: 0, already: 0, skipped: 0, fail: "", items: [] };
    // 归位：已在主城就不再动；不在就走选键表点固定坐标（不按返回键、不设次数上限）
    if (!ensureMainHud()) {
        out.fail = "归位失败：不在主城（已按选键表点固定坐标，不按返回键，下一轮心跳重试）";
        api.log("每日奖励：" + out.fail + "，本轮不做菜单项");
        return out;
    }
    logRedDot();
    recordItem(out, "每日奖励", claimDailyReward());
    // 关菜单回主界面：点底部菜单按钮收起（不按返回键，返回键会弹「确定要结束游戏吗」）
    if (!isMainHud()) {
        tapPct(MENU.btn, "菜单按钮（收起菜单）");
        api.sleep(1200);
    }
    if (!isMainHud()) {
        dismissExitDialog();
        try { api.ensureHome("每日领取"); } catch (e6) { }
    }
    return out;
}

// 单项记账：只有 claimed/already 计入任务条；skipped 明确不计；fail 记第一条原因
function recordItem(out, name, r) {
    out.items.push(name + "=" + r.kind + (r.why ? "(" + r.why + ")" : ""));
    if (r.kind === "claimed") { out.claimed++; out.done++; }
    else if (r.kind === "already") { out.already++; out.done++; }
    else if (r.kind === "skipped") { out.skipped++; }
    else if (!out.fail) { out.fail = name + "：" + (r.why || "失败"); }
    api.claimProgress(out.done, TOTAL_ITEMS);
    api.log("[记账] " + name + " → " + r.kind + (r.why ? "（" + r.why + "）" : "")
            + "｜累计核实 " + out.done + "/" + TOTAL_ITEMS + "（本次领到 " + out.claimed
            + "，此前已领 " + out.already + "，跳过 " + out.skipped + "）");
}

/* ==================== 第 4 项：每日分享邀请码 ====================
 * 判据链：去完成 →（点）→ 去领取 →（点）→ 不再有「去领取」。
 * 每一步都要真的看到文案变化；最后一步允许「消失」，但消失前必须见过「去领取」。
 * 通道顺序：OCR 认按钮 → 认不到就用图色（橙色按钮）点标定中心 → 都不行就回退重进。
 */
function claimShareInvite() {
    // 按钮区：右对齐的「去完成 / 去领取 / 已领取」，x 76~100%、y 36~58%（1280×720 → 973~1280 / 259~418）
    var R = [76, 36, 100, 58];
    var ROW = [55, 34, 100, 60];   // 整行兜底：有的机型按钮文字会被 OCR 切成两段
    // 终态：看到这些就说明这一项已经领过/领到了，不再要求「文案变化」
    var TERMINAL = TERMINAL_WORDS;
    var startMs = Date.now();
    var rounds = 0;
    var reported = false;
    var tappedOnce = false;
    var trail = [];
    while (rounds < ITEM_MAX_ROUNDS) {
        rounds++;
        var t0 = Date.now();
        var items = regionItems(R);
        var before = itemsText(items);

        // ① 终态优先：进页面就已是已领取态，也算这一项完成（没有文案变化可看）
        var term = pickItem(items, TERMINAL);
        if (term == null) {
            var rowItems = regionItems(ROW);
            var term2 = pickItem(rowItems, TERMINAL);
            if (term2 != null) { items = rowItems; before = itemsText(rowItems); term = term2; }
        }
        if (term != null) {
            if (tappedOnce) {
                api.log("第4项：本次刚领到（点完后文案「" + before + "」，终态「" + term.t
                        + "」）→ 完成，第 " + rounds + " 轮");
                return { ok: true, rounds: rounds, already: false };
            }
            api.log("第4项：本来就已领（进页面即「" + term.t + "」，本项此前已领过）→ 记完成，本次未点击");
            return { ok: true, rounds: rounds, already: true };
        }

        // ② 文案里没有「去完成/去领取」也没有终态 → 页面可能没打开
        if (pickItem(items, ["去完成", "去领取"]) == null) {
            api.log("第4项·第" + rounds + "轮：按钮区域既没有「去完成/去领取」也没有终态（区域 "
                    + R.join(",") + "，认出：" + (before || "空") + "）→ 按页面没打开处理");
            // 通道 2：图色（橙色按钮）→ 点标定中心，点完仍要验文案变化
            var orange = orangeAt(ACT.shareRect);
            if (orange >= 18) {
                api.log("第4项·第" + rounds + "轮：图色命中（橙色 " + orange + "% ≥18%）→ 点按钮中心");
                tappedOnce = true;
                tapPct(ACT.shareBtn, "第4项按钮（图色通道）");
                api.sleep(1700);
                var afterO = itemsText(regionItems(R));
                if (afterO !== before && pickItem(regionItems(R), ["去完成", "去领取"]) == null) {
                    api.log("第4项：图色点击后文案「" + (before || "空") + "」→「" + (afterO || "消失")
                            + "」→ 每日分享邀请码成功（第 " + rounds + " 轮）");
                    return { ok: true, rounds: rounds };
                }
                api.log("第4项：图色点击后文案＝「" + (afterO || "空") + "」，没看到预期变化，继续磨");
                trail.push("轮" + rounds + " 图色:橙" + orange + "% 点(86.7,46.4)→" + (afterO || "空"));
            } else {
                trail.push("轮" + rounds + " OCR:无按钮（" + (before || "空") + "）图色:橙" + orange + "%");
            }
            if (!reported && Date.now() - startMs >= STUCK_REPORT_MS) {
                reported = true;
                reportStuck("第4项 每日分享邀请码（英雄集结页）", rounds, R, trail);
            }
            // 通道 3：回退重进
            if (rounds % ROUNDS_BEFORE_REENTER === 0) {
                api.log("第4项：连续 " + ROUNDS_BEFORE_REENTER + " 轮没找到按钮，回退重进（X → 返回 → 活动 → 英雄集结）");
                backToMain();
                if (!enterActivityPage() || !enterHeroPage()) api.log("第4项：重进英雄集结失败，下一轮继续试");
            }
            api.log("第4项·第" + rounds + "轮结束（" + Math.round((Date.now() - t0) / 1000) + "s）");
            api.sleep(800);
            continue;
        }

        // ② 先「去完成」，没有再「去领取」
        var target = pickItem(items, ["去完成"]);
        var stage = "去完成";
        if (target == null) { target = pickItem(items, ["去领取"]); stage = "去领取"; }
        api.log("第4项·第" + rounds + "轮：OCR 按钮文案「" + target.t + "」（阶段 " + stage + "）@("
                + target.cx + "," + target.cy + ") → 点它");
        var tapped = tapItem(target, "第4项「" + stage + "」");
        if (tapped) tappedOnce = true;
        api.sleep(1700);
        var items2 = regionItems(R);
        var after = itemsText(items2);

        if (!tapped) {
            trail.push("轮" + rounds + " 点「" + target.t + "」被拒");
        } else if (after === before) {
            api.log("第4项：点完文案没变（点前「" + before + "」→ 点后「" + after + "」）→ 本轮记失败，继续磨");
            trail.push("轮" + rounds + " 点「" + target.t + "」→ 文案未变（" + after + "）");
        } else if (stage === "去完成" && pickItem(items2, ["去领取"]) != null) {
            // 去完成 → 去领取：文案已按预期变化，再点一次把奖励领掉
            var second = pickItem(items2, ["去领取"]);
            api.log("第4项：文案已变「去完成」→「" + second.t + "」@(" + second.cx + "," + second.cy
                    + ") → 再点一次领取");
            var ok2 = tapItem(second, "第4项「去领取」（第二次）");
            api.sleep(1800);
            var items3 = regionItems(R);
            var after2 = itemsText(items3);
            if (ok2 && after2 !== after && pickItem(items3, ["去领取"]) == null) {
                api.log("第4项：再点后文案「" + after + "」→「" + (after2 || "消失")
                        + "」→ 每日分享邀请码成功（第 " + rounds + " 轮）");
                return { ok: true, rounds: rounds };
            }
            api.log("第4项：再点后文案＝「" + (after2 || "空") + "」，仍在可领态，继续磨");
            trail.push("轮" + rounds + " 去完成→去领取 已变，再点后=" + (after2 || "空"));
        } else if (pickItem(items2, ["去完成", "去领取"]) == null) {
            // 文案变成非「去完成/去领取」（已领取态或按钮消失），且确实变了
            api.log("第4项：文案已变「" + before + "」→「" + (after || "消失")
                    + "」→ 每日分享邀请码成功（第 " + rounds + " 轮）");
            return { ok: true, rounds: rounds };
        } else {
            api.log("第4项：文案变了但仍可领（" + before + " → " + after + "），继续磨");
            trail.push("轮" + rounds + " " + before + "→" + after + " 仍可领");
        }

        if (!reported && Date.now() - startMs >= STUCK_REPORT_MS) {
            reported = true;
            reportStuck("第4项 每日分享邀请码（英雄集结页）", rounds, R, trail);
        }
        if (rounds % ROUNDS_BEFORE_REENTER === 0) {
            api.log("第4项：连续 " + ROUNDS_BEFORE_REENTER + " 轮没点成，回退重进（X → 返回 → 活动 → 英雄集结）");
            backToMain();
            if (!enterActivityPage() || !enterHeroPage()) api.log("第4项：重进英雄集结失败，下一轮继续试");
        }
        api.log("第4项·第" + rounds + "轮结束（" + Math.round((Date.now() - t0) / 1000) + "s）");
        api.sleep(600);
    }
    api.log("第4项：已试 " + rounds + " 轮（OCR/图色交替 + 回退重进）仍未看到文案变化 → 记失败，第 5 项不执行");
    reportStuck("第4项 每日分享邀请码（英雄集结页，已放弃）", rounds, R, trail);
    return { ok: false, rounds: rounds };
}

/* ==================== 第 5 项：殷海萨的祝福 ====================
 * 判据：面板按钮是「祈福」（今日免费未用）→ 点 → 变成「重新祈福」= 本次祈福生效。
 * 反例（345 实机 05:24 抓到）：今日免费已用，点「祈福」位会弹出「提示：消耗10钻石重新祈福」，
 * 此时**绝对不能点橙色「重新祈福」**（会花钻石），必须点「取消」，并把该项按「今日已祈福」计成功。
 */
var BLESS_BTN_R = [50, 64, 78, 84];   // 面板底部按钮（祈福/重新祈福）
var BLESS_DLG_R = [26, 25, 74, 70];   // 「提示」弹窗（含 消耗/钻石/取消）

// 弹窗是否在：认出「消耗」或「钻石」即为「重新祈福要花钻石」确认框
function blessDialog() {
    var items = regionItems(BLESS_DLG_R);
    if (pickItem(items, ["消耗", "钻石"]) != null) return { items: items, txt: itemsText(items) };
    return null;
}

// 点取消关掉「花钻石」弹窗；返回是否已关掉（认不到 消耗/钻石 了）
function blessCancelDialog(dlg) {
    var cancel = pickItem(dlg.items, ["取消"]);
    if (cancel != null) tapItem(cancel, "第5项「取消」（不花钻石）");
    else tapPct([41.0, 59.2], "第5项「取消」兜底坐标");
    api.sleep(1200);
    return blessDialog() == null;
}

// 面板里是否已经出现「重新祈福」：按钮区先看，认不全再扫整个面板下半部
// （OCR 有时只切到「祈福」两个字，会把「重新」吃掉）
function panelShowsRebless() {
    var items = regionItems(BLESS_BTN_R);
    if (pickItem(items, ["重新"]) != null) return itemsText(items);
    var wide = regionItems([30, 52, 100, 95]);
    if (pickItem(wide, ["重新"]) != null) return itemsText(wide);
    return "";
}

// 「重新祈福要花钻石」弹窗的处理（统一入口）：一律取消，绝不点确认；
// 取消后回看面板，只有真的读到「重新祈福」才算免费祈福已生效，否则该项不计完成。
function blessAfterPaidDialog(dlg, rounds, from) {
    api.log("第5项：付费弹窗已取消（已拒绝付费重新祈福，未消耗钻石）｜来源=" + from
            + "｜弹窗内容=" + dlg.txt);
    blessCancelDialog(dlg);
    var hit = panelShowsRebless();
    if (hit) {
        api.log("第5项：取消后看清面板已有「重新祈福」（" + hit + "）→ 免费祈福成功（今日已生效），记完成（第 "
                + rounds + " 轮）");
        return { ok: true, rounds: rounds, free: true };
    }
    api.log("第5项：取消后面板里看不到「重新祈福」→ 该项不计完成（付费弹窗不算成功）");
    return { ok: false, rounds: rounds, paid: true, why: "付费弹窗已取消，但面板里没读到「重新祈福」" };
}

function claimBless() {
    var startMs = Date.now();
    var rounds = 0;
    var reported = false;
    var trail = [];
    while (rounds < ITEM_MAX_ROUNDS) {
        rounds++;
        var t0 = Date.now();

        // ① 先看弹窗：出现「消耗10钻石重新祈福」= 今天免费祈福已经用过
        var dlg = blessDialog();
        if (dlg != null) {
            return blessAfterPaidDialog(dlg, rounds, "进入时就有弹窗（上一轮残留）");
        }

        // ② 面板按钮文案
        var items = regionItems(BLESS_BTN_R);
        var txt = itemsText(items);
        if (pickItem(items, ["重新"]) != null) {
            api.log("第5项：免费祈福成功（面板按钮为「" + txt + "」，今日已生效，本次未点击，第 " + rounds + " 轮）");
            return { ok: true, rounds: rounds, free: true };
        }
        var qf = pickItem(items, ["祈福", "新福", "析福"]);
        if (qf == null) {
            api.log("第5项：祈福按钮没找到（OCR 区域 " + BLESS_BTN_R.join(",")
                    + "，认出：" + (txt || "空") + "）");
            // 通道 2：亮块（金色按钮）→ 点标定中心，点完必须先查弹窗
            var bright = 0;
            try { bright = api.brightRatio(ACT.blessRect, 150); } catch (e) { bright = 0; }
            if (bright >= 12) {
                api.log("第5项·第" + rounds + "轮：图色命中（亮块 " + bright + "% ≥12%）→ 点「祈福」中心");
                tapPct(ACT.blessBtn, "第5项「祈福」（图色通道）");
                api.sleep(1800);
                var dlgO = blessDialog();
                if (dlgO != null) {
                    return blessAfterPaidDialog(dlgO, rounds, "图色通道点击「祈福」后");
                }
                var afterO = regionItems(BLESS_BTN_R);
                if (pickItem(afterO, ["重新"]) != null) {
                    api.log("第5项：免费祈福成功（图色通道，「" + txt + "」→「" + itemsText(afterO)
                            + "」，第 " + rounds + " 轮）");
                    return { ok: true, rounds: rounds, free: true };
                }
                api.log("第5项：点了没反应（图色通道，点前「" + txt + "」→ 点后「"
                        + (itemsText(afterO) || "空") + "」），继续磨");
                trail.push("轮" + rounds + " 图色:亮" + bright + "%→" + (itemsText(afterO) || "空"));
            } else {
                trail.push("轮" + rounds + " OCR:无祈福（" + (txt || "空") + "）图色:亮" + bright + "%");
            }
            if (!reported && Date.now() - startMs >= STUCK_REPORT_MS) {
                reported = true;
                reportStuck("第5项 殷海萨的祝福（祈福按钮）", rounds, BLESS_BTN_R, trail);
            }
            if (rounds % ROUNDS_BEFORE_REENTER === 0) {
                api.log("第5项：连续 " + ROUNDS_BEFORE_REENTER + " 轮没找到祈福按钮，回退重进（X → 返回 → 活动 → 殷海萨的祝福）");
                backToMain();
                if (!enterActivityPage()) api.log("第5项：重进活动页失败，下一轮继续试");
                else {
                    var nav = findAny(["殷海萨的祝福", "股海萨的祝福", "殷海萨的视祝福"], [0, 12, 34, 74]);
                    if (nav != null) {
                        api.log("点左侧导航「" + nav.hit.text + "」@(" + nav.hit.cx + "," + nav.hit.cy + ")");
                        try { api.tap(nav.hit.cx, nav.hit.cy); } catch (e) { }
                        api.sleep(2600);
                    } else api.log("第5项：活动页里认不到「殷海萨的祝福」入口");
                }
            }
            api.log("第5项·第" + rounds + "轮结束（" + Math.round((Date.now() - t0) / 1000) + "s）");
            api.sleep(800);
            continue;
        }

        // ③ 点「祈福」→ 先查弹窗（防花钻石）→ 再验文案变化
        api.log("第5项·第" + rounds + "轮：OCR 按钮文案「" + qf.t + "」@(" + qf.cx + "," + qf.cy + ") → 点「祈福」");
        var tapped = tapItem(qf, "第5项「祈福」");
        api.sleep(1800);
        if (!tapped) {
            trail.push("轮" + rounds + " 点「" + qf.t + "」被拒");
        } else {
            var dlg2 = blessDialog();
            if (dlg2 != null) {
                return blessAfterPaidDialog(dlg2, rounds, "OCR 通道点击「祈福」后");
            }
            var items2 = regionItems(BLESS_BTN_R);
            var txt2 = itemsText(items2);
            if (pickItem(items2, ["重新"]) != null) {
                api.log("第5项：免费祈福成功（「" + txt + "」→「" + txt2 + "」，第 " + rounds + " 轮）");
                return { ok: true, rounds: rounds, free: true };
            }
            if (txt2 === txt) {
                api.log("第5项：点了没反应（点前「" + txt + "」→ 点后「" + txt2 + "」）→ 本轮记失败，继续磨");
                trail.push("轮" + rounds + " 点「" + qf.t + "」→文案未变（" + txt2 + "）");
            } else {
                api.log("第5项：点了没反应/文案变了但不是「重新祈福」（" + txt + " → " + (txt2 || "空") + "），继续磨");
                trail.push("轮" + rounds + " " + txt + "→" + (txt2 || "空") + " 非重新祈福");
            }
        }

        if (!reported && Date.now() - startMs >= STUCK_REPORT_MS) {
            reported = true;
            reportStuck("第5项 殷海萨的祝福（祈福按钮）", rounds, BLESS_BTN_R, trail);
        }
        if (rounds % ROUNDS_BEFORE_REENTER === 0) {
            api.log("第5项：连续 " + ROUNDS_BEFORE_REENTER + " 轮没点成，回退重进（X → 返回 → 活动 → 殷海萨的祝福）");
            backToMain();
            if (!enterActivityPage()) api.log("第5项：重进活动页失败，下一轮继续试");
            else {
                var nav2 = findAny(["殷海萨的祝福", "股海萨的祝福", "殷海萨的视祝福"], [0, 12, 34, 74]);
                if (nav2 != null) {
                    api.log("点左侧导航「" + nav2.hit.text + "」@(" + nav2.hit.cx + "," + nav2.hit.cy + ")");
                    try { api.tap(nav2.hit.cx, nav2.hit.cy); } catch (e) { }
                    api.sleep(2600);
                } else api.log("第5项：活动页里认不到「殷海萨的祝福」入口");
            }
        }
        api.log("第5项·第" + rounds + "轮结束（" + Math.round((Date.now() - t0) / 1000) + "s）");
        api.sleep(600);
    }
    api.log("第5项：已试 " + rounds + " 轮仍未看到「重新祈福」→ 记失败");
    reportStuck("第5项 殷海萨的祝福（已放弃）", rounds, BLESS_BTN_R, trail);
    return { ok: false, rounds: rounds };
}

/* ==================== 第 4 + 5 项总编排（一次进页面做完再返回） ==================== */

function runActivityItems(baseDone) {
    var base = baseDone || 0;
    var res = { ok: false, done: base, msg: "" };
    if (!ensureMainHud()) {
        res.msg = "活动页入口没打开：不在主城（已按选键表点固定坐标，不按返回键，下一轮心跳重试）";
        api.log("第4/5项：" + res.msg);
        return res;
    }
    if (!enterActivityPage()) {
        res.msg = "活动页没打开（点了顶栏「活动」3 次，11s 内都认不到左侧「英雄集结」）";
        api.log("第4/5项：" + res.msg);
        reportStuck("第4/5项 活动页入口", 3, [0, 0, 100, 20], ["点「活动」3 次都没进活动页"]);
        return res;
    }

    // 第 4 项（进入页面/打开面板/扫描这些动作一律不动任务条，只有确认成功才 +1）
    if (!enterHeroPage()) {
        res.msg = "第4项：英雄集结面板没打开（点了左侧「英雄集结」认不到「每日分享邀请码」）";
        api.log("第4项：" + res.msg + "，第 5 项不执行");
        reportStuck("第4项 英雄集结面板", 1, [30, 22, 100, 62], ["点左侧「英雄集结」后面板没出现「每日分享邀请码」"]);
        return res;
    }
    var r4 = claimShareInvite();
    if (!r4.ok) {
        res.msg = "第4项（每日分享邀请码）磨 " + r4.rounds + " 轮仍未成功，第 5 项按未执行处理";
        api.log("第4项失败：" + res.msg + "（任务条停在 " + res.done + "/" + TOTAL_ITEMS + "，不碰第 5 项）");
        return res;
    }
    res.done = base + 1;
    api.log("第4项" + (r4.already ? "本来就已领" : "本次刚领到") + "（第 " + r4.rounds + " 轮）→ 记完成");
    api.claimProgress(res.done, TOTAL_ITEMS);   // 只在成功判定那一行之后跳
    api.log("接着做第 5 项：同页面左侧「殷海萨的祝福」");
    // 点「去领取」常会弹分享/奖励小窗，把左侧导航盖住了 → 先消弹窗再找导航（不按返回键）
    var pg = pageName();
    if (pg.indexOf("英雄集结") < 0) {
        api.log("第4项后当前页面=" + pg + "（被分享/奖励小窗盖住）→ 消弹窗/回主页（不按返回键）");
        dismissExitDialog();
        try { api.ensureHome("每日领取-第4项关窗"); } catch (e) { }
        api.sleep(1500);
        api.log("关窗后页面=" + pageName());
    }

    // 第 5 项（同一个活动页，不返回，直接点左侧导航）
    // 注意：这里**先不动任务条**（仍停在 4/5）——只有免费祈福真的生效才写 5/5。
    var nav = findAny(["殷海萨的祝福", "股海萨的祝福", "殷海萨的视祝福"], [0, 12, 34, 74]);
    if (nav == null) {
        api.log("第5项：英雄集结页里找不到左侧导航「殷海萨的祝福」，先回活动页再进");
        if (!enterActivityPage()) {
            res.msg = "第5项：回活动页失败，认不到「殷海萨的祝福」";
            return res;
        }
        nav = findAny(["殷海萨的祝福", "股海萨的祝福", "殷海萨的视祝福"], [0, 12, 34, 74]);
    }
    if (nav == null) {
        res.msg = "第5项：活动页里认不到「殷海萨的祝福」入口";
        api.log("第5项：" + res.msg);
        reportStuck("第5项 殷海萨的祝福入口", 1, [0, 12, 34, 74], ["活动页左侧导航认不到「殷海萨的祝福」"]);
        return res;
    }
    api.log("点左侧导航「" + nav.hit.text + "」@(" + nav.hit.cx + "," + nav.hit.cy + ")");
    try { api.tap(nav.hit.cx, nav.hit.cy); } catch (e) { }
    api.sleep(2600);
    var opened = findAny(["祈福", "新福", "重新祈福", "当前祝福积分"], [35, 55, 100, 95]);
    if (opened == null) {
        api.log("第5项：点了「殷海萨的祝福」面板没打开（认不到祈福/当前祝福积分），进入重试");
    } else {
        api.log("第5项：殷海萨的祝福面板已打开（认出「" + opened.hit.text + "」）");
    }
    var r5 = claimBless();
    if (!r5.ok) {
        res.msg = "第5项（殷海萨的祝福）：" + (r5.why || ("磨 " + r5.rounds + " 轮仍未出现「重新祈福」"));
        api.log("第5项失败：" + res.msg + "（任务条停在 " + res.done + "/" + TOTAL_ITEMS + "）");
        return res;
    }
    res.done = base + 2;
    api.claimProgress(res.done, TOTAL_ITEMS);
    api.log("第5项完成（任务条 " + res.done + "/" + TOTAL_ITEMS + "）：免费祈福成功"
            + (r5.free ? "（免费那次已生效）" : ""));

    // 两项都完成，统一返回
    backToMain();
    res.ok = true;
    return res;
}

/* ============================ 执行 ============================ */

// manual=true = 用户手点的（失败不消耗当天重试次数，只在成功时记账）
function run(reason, manual) {
    if (!api.gameInProgress()) {
        api.log("游戏不在前台，先切到游戏再执行（" + reason + "）");
    }
    if (manual) api.dailyMarkManualRun("daily_claim", reason);
    else api.dailyMarkRun("daily_claim", reason);
    api.log("开始执行（" + reason + "）：本轮 1 项（每日奖励）；逐项进页面看按钮态，画面真的变化才记账"
            + "（红点只打日志，不参与判断）");
    var startMs = Date.now();
    setState("执行中…");
    // 1 项（每日奖励）全程挂在「每日领取」任务条上（纯 JS 驱动，自己保住 daily 状态）
    api.taskBegin("每日领取", 1800);
    api.claimProgress(0, TOTAL_ITEMS);

    // 1) 只剩「每日奖励」一项（421：邮件、成长支援都已摘除）
    var s = runScriptItems();
    api.log("[每日奖励核对] " + s.items.join("｜") + "｜本次领到 " + s.claimed + "，此前已领 "
            + s.already + "，跳过 " + s.skipped + (s.fail ? "，失败：" + s.fail : ""));
    if (s.fail) {
        return finishFail(reason, manual, startMs, "每日奖励：" + s.fail, s.done);
    }
    if (s.claimed + s.already === 0) {
        return finishFail(reason, manual, startMs,
                "每日奖励没核实到领取（既没有可领取也没有终态），不记账", s.done);
    }

    // 2) 第 4/5 项（英雄集结 / 殷海萨的祝福）：流程还在等用户确认，本轮不接入、不点屏。
    return finishThirdItems(reason, startMs, s);
}

// 收口：421 起只剩「每日奖励」一项，照实报领到/此前已领/跳过，不写未接入项
function finishThirdItems(reason, startMs, s) {
    var sec = Math.max(1, Math.round((Date.now() - startMs) / 1000));
    var msg = "本次领到 " + s.claimed + " 项，此前已领 " + s.already + " 项"
            + (s.skipped > 0 ? "，无按钮跳过 " + s.skipped + " 项（未记账）" : "")
            + "；用时 " + sec + " 秒";
    api.dailyMarkDone("daily_claim", msg);
    api.log("完成（" + reason + "）：" + msg);
    api.event("每日领取完成（" + reason + "）：" + msg);
    setState("每日奖励已核对");
    api.sleep(3000);
    api.taskEnd();
    return true;
}

// 失败收口：manual 不消耗当天重试次数，但也不会写「完成」
function finishFail(reason, manual, startMs, why, done) {
    var sec = Math.max(1, Math.round((Date.now() - startMs) / 1000));
    api.log("未完成（" + reason + "）：" + why + "，用时 " + sec + "s；任务条停在 "
            + done + "/" + TOTAL_ITEMS + "，未核实的项不计完成");
    if (manual) {
        api.event("手动执行未完成：" + why + "（不计入今日失败次数）");
    } else {
        api.dailyMarkFail("daily_claim", why);
    }
    setState("失败：" + why);
    api.taskEnd();
    return false;
}

/* ============================ 判据迁移 ============================ */

// 2026-11-03 v13：旧判据把「还在正常跑的脚本」记成超时失败，8 次就把今天标成
// 「今日放弃」，任务栏有可领奖励也不再领。升级到本版时清掉当天这条误判记录，重领一次。
function migrateJudge() {
    if (api.loadConfigInt("judge_ver", 0) >= 13) return;
    api.putConfigInt("judge_ver", 13);
    var brief = "";
    try { brief = String(api.dailyBrief("daily_claim") || ""); } catch (e) { brief = ""; }
    if (brief.indexOf("放弃") >= 0) {
        api.dailyReset("daily_claim");
        api.log("旧判据误判「今日放弃」（脚本其实跑完了），已清除今日记录，重新领一次");
    }
}

/* ============================ onTick（轻，禁 sleep，禁一切阻塞调用） ============================ */

// A1：onTick 跑在主线程（ScriptModule.onTick ← ModuleManager.tick），这里只做
// 「该不该跑」的判定并置状态文本；实际领取动作由本函数返回 true 请求宿主
// ScriptModule.runOnce 起自己的 js 线程去执行 —— 那里阻塞点屏/OCR 才安全。
// （2026-11-02 教训：onTick 里直接跑整套领取，主线程被阻塞几百秒会 ANR。）
function onTick(nowMs) {
    migrateJudge();
    if (Date.now() - lastCheck < 1000) return false;
    lastCheck = Date.now();
    if (Date.now() - bootAt < BOOT_GRACE_MS) return false;   // 刚重启，等截屏就绪
    if (!api.gameInProgress()) return false;                 // 不在游戏里不乱点
    // 341：被拦下也要留痕，写清完成时间 —— 394 起只在「刚进入已完成」时记一条（状态驱动，不做时间门）
    if (api.dailySettled("daily_claim")) {
        if (!settledLogged) {
            settledLogged = true;
            var brief = "";
            try { brief = String(api.dailyBrief("daily_claim") || ""); } catch (e) { brief = ""; }
            api.log("今日已领过（" + (brief.length > 0 ? brief : "今日已完成")
                    + "）→ 记账挡住（daily.day + daily.st.<dayKey>），不再跑；与时间段无关");
        }
        return false;
    }
    settledLogged = false;
    if (api.stepsRunning()) return false;                    // 步骤脚本在跑
    if (api.autoDailyScheduling()) return false;             // 交给总调度，不抢
    if (!longTaskAllows()) return false;                     // 334：副本/神域/进游戏/复活在跑 → 不插队
    // 338 起没有静音时段；344 又把「05:00 后随机延迟」删了：
    // 换日（minutesSinceReset 归零）后条件满足立刻跑，不做任何人为推迟。
    if (!api.captureRunning()) return false;                 // 没画面别跑（OCR 拿旧帧）
    // 394：删掉 retryGapMs / RETRY_GAP_MS 重试间隔 —— 条件满足就立刻跑，失败下一轮继续。
    setState("该跑了，交给宿主线程执行");
    return true;   // 请求宿主 ScriptModule.runOnce 异步执行（主线程绝不阻塞）
}

/* ============================ MOD 导出 ============================ */

// MOD 导出：ScriptHost.build 依它判定脚本可用；ScriptModule 从这里取
// id/title/desc/defaultEnabled/status/onTick/runOnce。
// 2026-11-11：**不要再写 order**。调度顺序统一由 Java DailyClaimModule.order()=14 决定
// （ScriptModule.order() 有原生兜底时直接取原生值，脚本里的数字不参与排序），
// 只有纯脚本模块才用脚本里的 order。这样全队只有一张 order 表，不会再出现两处数字打架。
var MOD = {
    id: "daily_claim",
    title: "每日领取",
    desc: "1 项：每日奖励（421 起邮件、成长支援都已从每日领取摘除）",
    defaultEnabled: true,   // 414：默认勾选。重装/清数据后设置被清空，原来默认 false 会导致"没有进行中的任务"、整机不产生日志
    // status：无入参，返回中文状态串；UI 线程调用，只读配置/内存标记，不点屏。
    status: function () {
        if (!api.loadConfigBool("on", true)) return "未勾选";
        if (api.stepsRunning()) return "领取中";
        if (api.dailyDone("daily_claim")) return "今日已领";
        if (api.dailySettled("daily_claim")) return "今日放弃";
        return api.gameInProgress() ? "待执行" : "等游戏";
    },
    onTick: onTick,
    // runOnce 入参 reason=触发文案（null 按"手动"）；返回 boolean（脚本是否跑成功）。
    // manual 判定：reason 为 null 或以「手动」开头 → 失败不消耗当天重试次数。
    // 副作用：同步点屏/等待/OCR（纯 JS 驱动，不再走 ActionFlow 脚本），由 ScriptModule 的 js 线程承载。
    runOnce: function (reason) {
        if (api.stepsRunning()) return false;
        // reason=手动 → 不消耗当天重试次数；编排/自动触发 → 正常记账
        var manual = reason == null || String(reason).indexOf("手动") === 0;
        return run(reason == null ? "手动" : reason, manual);
    }
};

// [本地打包验证 2026-11-13] 这一行只是标记，不影响逻辑
